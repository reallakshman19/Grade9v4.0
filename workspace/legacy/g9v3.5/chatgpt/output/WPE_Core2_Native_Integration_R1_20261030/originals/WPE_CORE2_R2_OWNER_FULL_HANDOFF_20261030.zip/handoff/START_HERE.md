# WPE Core2 — R2 Owner full handoff (updated 30 October 2026)

## Files

1. `original_immutable/WPE_CORE2_CODING_CANDIDATE_R1.zip` is the unmodified R1 ZIP with all 22 original contents, including the real 14-item R1 projection and any quoted source examination text. **Owner/private custody only.** SHA-256: `fca105392a2bcb579c9d382dc6d61afddb643af8b46d57d1fed2555a65f188a6`.
2. `agent_public_safe/WPE_CORE2_R2_ENGINEERING_HANDOFF_PUBLIC_SAFE_20261030.zip` is the unchanged public-safe engineering package, containing only code, synthetic fixture and up-to-date status. SHA-256: `d2a24619b1def84bcc538615f6032a94f4161a5697067f60984280f1186a40e2`. This is the file suitable for an approved Common public-safe relay, subject to repository review.
3. `handoff/` contains the current R6 scope correction, merged Progress Page receipt, owner handoff directions, and new local test logs.

## Current authoritative project context

Published Page revision R6; WBS **4.3.2** is the learner/native Core2 fidelity milestone. The old R1 package references R5/4.2.1; those are historical and are intentionally not rewritten. PR96 is merged at `c2235832566245452b29395b75ea4d0a4aeab4cd`, with readback.

## Scope and limits

Synthetic engine candidate self-tested 33/33 Python and 26/26 Chromium; real source selection unchanged at 14 HOLD, seven vacancies, zero independently admitted. Native Grade9v3.5 integration, governed renderer, independent QA, Physics academic admission, genuine exam golden, rights clearance, actual agent transfer and Owner product acceptance are NOT_RUN. Do not report complete Core2 from these files.

## Handoff route

The Owner can access these ZIPs here. A second agent cannot be claimed to have received them just because they appear in this conversation. For agent handoff, use the immutable Common public-safe artifact relay for the engineering ZIP, or the authorized Handoffs Drive for any source-bearing material. Verify recipient byte hash and access; publish sanitized Common receipt. The existing page remains marked OTM and does not activate any `g9v35` Cycle.

## Next two deliveries

E1 builder: integrate the candidate engine with exact current Grade9v3.5 canonical package, native renderer, and synthetic golden, using at least one failing negative case; return exact changes and tests. Then distinct technical QA reviews that exact native build. Physics review, independent admission and 21 authentic items remain separate and gating.

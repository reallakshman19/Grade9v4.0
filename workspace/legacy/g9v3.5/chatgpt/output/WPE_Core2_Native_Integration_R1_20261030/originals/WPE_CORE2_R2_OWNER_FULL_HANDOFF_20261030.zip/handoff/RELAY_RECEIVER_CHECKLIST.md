# Relay receiver checklist (not proof of transfer)

TRANSPORT: `LOCAL_ONLY_NOT_TRANSFERRED_TO_AGENT` at package creation.

- Sender: Oracle standalone, author of local engineering candidate; R6/4.3.2.
- Recipient: E1 integrator, **UNASSIGNED**; role/chat identity NOT_VERIFIED.
- Source: Common `skills/agent-work/ARTIFACT_RELAY.md`.
- Public-safe payload: `WPE_CORE2_R2_ENGINEERING_HANDOFF_PUBLIC_SAFE_20261030.zip`.
- Protected Owner-only payload: `WPE_CORE2_R2_OWNER_FULL_HANDOFF_20261030.zip`; DO NOT PUBLISH PUBLICLY.
- Step 1: authorized relay custodian commits public-safe ZIP to immutable Common `relay/AGENT_WORK/.../payload/` or approves alternate authorized private Drive source.
- Step 2: publish a sanitized Common relay record with exact SHA-256 and bytes, native task, and expected next actor; do not change V3.1 recorder.
- Step 3: recipient retrieves exact file through permitted route and reports measured size/hash and working tree source commit.
- Step 4: recipient checks key source contracts and returns an actual native build/negative test and PR/diff.
- Step 5: distinct reviewer obtains and checks that exact native return; Owner acceptance is separate.

Missing Step 1/2/3 means NOT_TRANSFERRED. Link or ZIP received in Owner chat alone does not complete this cross-agent route.

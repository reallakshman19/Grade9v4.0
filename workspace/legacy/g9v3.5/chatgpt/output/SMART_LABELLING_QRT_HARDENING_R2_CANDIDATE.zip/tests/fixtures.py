"""Synthetic contract fixtures. These are neither exams nor learner records."""
import copy
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "skills/smart-labelling-1/scripts"))
from qrt_contract import Checker, FACTORS, digest, file_digest


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


class Fixture:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        for name in ("lib.json", "vocab.json", "sl1.json", "sl2.json", "source.json"):
            (self.folder/name).write_bytes((ROOT/"tests/seeds"/name).read_bytes())
        self.s1, self.s2, self.source = (read(self.folder/name) for name in ("sl1.json", "sl2.json", "source.json"))
        self.r1, self.r2 = self.s1["records"][0], self.s2["records"][0]
        self.qid = self.r1["question_id"]
        self.r1["source_verification"].update(status="PARTIAL", provenance="SOURCE_UNVERIFIED")
        self.r1["status"] = self.r2["status"] = "UNREVIEWED"
        self.s1["library_ref"]["path"] = str(self.folder/"lib.json")
        self.s1["vocabulary_ref"]["path"] = str(self.folder/"vocab.json")
        self.s2["sl1_ref"]["path"] = str(self.folder/"sl1.json")
        self.s2["rubric_ref"]["path"] = str(self.folder/"vocab.json")
        self.r1["custody"]["source_file"] = str(self.folder/"source.json")
        self.contract = {"schema": "smart-labelling-qrt-contract/v2", "inputs": {}, "records": [{"question_id": self.qid}]}
        self.entry = self.contract["records"][0]
        item = self.source["items"][0]
        self.entry["source"] = {"adapter": "explicit-key-json/v1", "path": str(self.folder/"source.json"),
                                "item_id": item["id"], "figure_assets": []}
        self.entry["answer_reference"] = {"kind": "PUBLISHER_FIELD", "value": item["key"]}
        self.seed()
        save(self.folder/"registry.json", {"schema": "smart-labelling-review-registry/v2", "reviewers": [
            {"id": "synthetic-independent-reviewer", "status": "ACTIVE", "roles": ["sl1", "sl2", "source_custody", "key_custody", "answer_extraction", "qrt", "canonical", "construction", "runtime", "acceptance", "learner_interpretation"]}]})
        self.flush()

    def ref(self, name, locator=None):
        ref = {"path": str(self.folder/name), "sha256": file_digest(self.folder/name)}
        if locator is not None:
            ref["locator"] = locator
        return ref

    def source_digests(self):
        item = self.source["items"][0]
        adapter = self.entry["source"]["adapter"]
        payload = {"adapter": adapter, "item_id": item["id"], "stem": item["stem"], "options": item["options"],
                   "figs": item["figs"] if adapter == "examside-json/v1" else item["figure_note"], "format": item.get("type")}
        self.entry["source"].update(question_digest=digest(payload), answer_digest=digest({k: item[k] for k in ("key", "explanation") if k in item}))

    def flush(self, source_digests=True):
        for name, value in (("source.json", self.source), ("sl1.json", self.s1), ("sl2.json", self.s2)):
            save(self.folder/name, value)
        if source_digests:
            self.source_digests()
        self.entry["source"]["sha256"] = file_digest(self.folder/"source.json")
        self.entry["sl1_record_digest"] = digest(self.r1)
        self.entry["sl2_record_digest"] = digest(self.r2)
        self.contract["inputs"] = {key: self.ref(name) for key, name in (("sl1", "sl1.json"), ("sl2", "sl2.json"), ("library", "lib.json"), ("vocabulary", "vocab.json"))}
        save(self.folder/"contract.json", self.contract)

    def seed(self):
        scores = {k: self.r2["difficulty_evidence"]["components"][k]["score"] for k in FACTORS}
        self.entry["cognitive_seed"] = {
            "schema": "smart-labelling-cognitive-seed/v2",
            "inputs": [{"role": "synthetic given", "source_pointer": "/stem"}],
            "outputs": [{"role": "synthetic requested comparison", "source_pointer": "/stem"}],
            "decisive_roles": [{"id": "r1", "intellectual_work": "Synthetic role for testing record correspondence", "route_move_refs": ["m1", "m2"]}],
            "conditions": [{"condition": "Synthetic condition"}],
            "dependencies": [{"role": "Synthetic prerequisite", "authority_status": "UNQUALIFIED"}],
            "boundary_checks": [{"route_ref": "m2", "check": "Synthetic boundary"}],
            "wrong_move_hypotheses": [{"route_ref": "m1", "hypothesis_ref": 0, "status": "HYPOTHESIS"}],
            "competing_operations": [{"operation": "APPLY", "reason": "Synthetic competing interpretation for review"}],
            "operation_structure": {"claim": "Synthetic claim", "warrant": "Synthetic warrant requirement", "scope": "Synthetic scope"},
            "independent_demand": {"assessor": "synthetic", "basis": "TASK_INTRINSIC", "prior_score_seen": False,
                                   "operation": "JUSTIFY", "scores": scores, "factor_route_refs": {k: ["m2"] for k in FACTORS}, "prior_comparison": None}}

    def review(self, name, role, subject, decision, author="synthetic"):
        save(self.folder/name, {"schema": "smart-labelling-review/v2", "role": role, "status": "APPROVED", "reviewer": "synthetic-independent-reviewer",
                               "author": author, "subject_digest": digest(subject), "findings": "SYNTHETIC TEST RECEIPT ONLY; no academic approval",
                               "evidence_refs": [self.ref("source.json", "/items/0")], "decision": decision})
        return self.ref(name)

    def evidence(self, help_value="INDEPENDENT", unknown=False):
        self.r2["mode"] = "EVIDENCE"
        help_value = "UNKNOWN" if unknown else help_value
        committed = help_value in {"INDEPENDENT", "UNKNOWN"}
        attempt = {"attempt_id": "A1", "question_id": self.qid, "task_id": self.qid,
                   "question_version": self.r1["version"], "question_digest": self.entry["source"]["question_digest"],
                   "item_digest": self.r1["custody"]["item_digest"], "stage": "P1", "saved": True,
                   "save_sequence": 2, "feedback_sequence": 3 if committed else 1,
                   "date": "2026-10-30", "answer": "A", "reasoning": "Synthetic unelaborated response.", "confidence": "SURE",
                   "help_before_commit": help_value, "committed_before_feedback": committed,
                   "exposures_before_save": [] if help_value in {"INDEPENDENT", "UNKNOWN"} else [help_value], "time_taken_s": 40}
        self.attempts = {"schema": "g9v35-p1-attempts/v1", "attempts": [attempt]}
        self.attempt = attempt
        learner = self.r2["learner"]
        learner.update(attempt_ref="A1", original_answer=attempt["answer"], reasoning=attempt["reasoning"], confidence=attempt["confidence"],
                       committed_before_feedback=committed, help_exposure=help_value, result="NOT_EVALUATED", failure_hypothesis=None)
        self.save_attempts()

    def save_attempts(self, refresh_snapshot=True):
        save(self.folder/"attempts.json", self.attempts)
        spec = self.entry.setdefault("observation", {})
        spec.update(attempts_ref=self.ref("attempts.json"), attempt_id="A1", stage="P1", task_id=self.qid)
        if refresh_snapshot:
            spec["snapshot_digest"] = digest(self.attempt)
        self.flush()

    def source_subject(self):
        return {"question_id": self.qid, "question_digest": self.entry["source"]["question_digest"], "identity": self.r1["source_identity"]}

    def official(self):
        (self.folder/"official-paper.txt").write_text("Synthetic official-paper artifact; not a real examination.\n", encoding="utf-8")
        (self.folder/"official-key.txt").write_text("Synthetic key row A; not an official key.\n", encoding="utf-8")
        paper_refs = [self.ref("official-paper.txt", "line:1 synthetic item")]
        key_refs = [self.ref("official-key.txt", "line:1 synthetic key")]
        self.entry["official_source"] = {"evidence_refs": paper_refs,
            "review_ref": self.review("paper-review.json", "source_custody", {**self.source_subject(), "evidence_refs": paper_refs},
                                     {"source_item_id": self.entry["source"]["item_id"], "paper": self.r1["source_identity"]["paper"],
                                      "question_digest": self.entry["source"]["question_digest"], "official_item_locator": "synthetic:1"})}
        key_subject = {**self.source_subject(), "source_answer_digest": self.entry["source"]["answer_digest"], "answer": "A", "evidence_refs": key_refs}
        self.entry["official_key"] = {"evidence_refs": key_refs,
            "review_ref": self.review("key-review.json", "key_custody", key_subject,
                                     {"source_item_id": self.entry["source"]["item_id"], "answer": "A", "option_mapping": {
                                         "kind": "MCQ", "source_options_digest": digest(self.source["items"][0]["options"]), "source_answer": "A",
                                         "official_answer": "A", "official_to_source": {"A": "A"}}, "official_key_locator": "synthetic:1"})}
        self.flush()

    def qrt_subject(self):
        return {"question_id": self.qid, "question_digest": self.entry["source"]["question_digest"], "answer_digest": self.entry["source"]["answer_digest"],
                "sl1_record_digest": digest(self.r1), "sl2_record_digest": digest(self.r2), "seed": self.entry["cognitive_seed"],
                "library_semantic_digest": digest(read(self.folder/"lib.json")),
                "rubric_sha256": self.contract["inputs"]["vocabulary"]["sha256"]}

    def qrt(self, source_role="PREREQUISITE_BRIDGE", operation="JUSTIFY", target_operation="JUSTIFY"):
        first = {"schema": "smart-labelling-independent-demand/v2", "question_id": self.qid,
                 "question_digest": self.entry["source"]["question_digest"], "rubric_sha256": self.contract["inputs"]["vocabulary"]["sha256"],
                 "assessor": "synthetic-independent-reviewer", "prior_score_seen": False, "operation": operation,
                 "scores": dict(self.entry["cognitive_seed"]["independent_demand"]["scores"]), "saved_sequence": 1,
                 "factor_evidence": {k: "Synthetic factor evidence only; no academic qualification" for k in FACTORS}}
        save(self.folder/"first-assessment.json", first)
        decision = {"operation": operation, "scores": dict(self.entry["cognitive_seed"]["independent_demand"]["scores"]), "independently_scored": True,
                    "first_assessment_ref": self.ref("first-assessment.json"), "comparison_sequence": 2,
                    "source_role": source_role, "target": {"operation": target_operation, "band": "D3"},
                    "primary_home": "SYNTHETIC-HOME", "secondary_homes": [], "differences": "Synthetic alternative independently adjudicated"}
        self.qrt_decision = decision
        self.entry["qrt_review_ref"] = self.review("qrt-review.json", "qrt", self.qrt_subject(), decision)
        self.flush()

    def span(self, name, line=1):
        text = (self.folder/name).read_text(encoding="utf-8").splitlines(keepends=True)[line-1]
        return {"artifact": self.ref(name), "start_line": line, "end_line": line, "text_sha256": "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()}

    def bound(self):
        save(self.folder/"authority.json", {"synthetic_warrant": {"statement": "Synthetic relation", "status": "CANDIDATE"}})
        warrant_subject = {"id": "W-SYNTHETIC", "pointer": "/synthetic_warrant", "warrant_digest": digest(read(self.folder/"authority.json")["synthetic_warrant"]), "authority_version": "test-1"}
        qualification = {"qualified": True, "conditions": ["Synthetic test only"]}
        warrant_ref = self.review("warrant-review.json", "canonical", warrant_subject, qualification)
        self.entry["canonical"] = {"warrants": [{"id": "W-SYNTHETIC", "artifact": self.ref("authority.json"), "pointer": "/synthetic_warrant",
            "authority_version": "test-1", "author": "synthetic", "review_ref": warrant_ref}]}
        self.canonical_result = [{**warrant_subject, "qualification": qualification, "review_ref": warrant_ref}]
        for name, value in (("teacher.txt", "Synthetic teacher role evidence.\n"), ("learner.txt", "Synthetic fresh reconstruction role evidence.\n"),
                            ("compiled.txt", "Synthetic compiled output.\n"), ("baseline.txt", "Synthetic baseline output.\n")):
            (self.folder/name).write_text(value, encoding="utf-8")
        save(self.folder/"blueprint.json", {"schema": "synthetic-blueprint", "version": "test"})
        save(self.folder/"adapter.json", {"schema": "synthetic-adapter", "version": "test"})
        self.entry["construction"] = {"task_id": "TASK-SYNTHETIC-MAIN", "source_question_id": self.qid, "source_role": self.qrt_decision["source_role"],
            "family_id": "FAMILY-SYNTHETIC", "author": "synthetic",
            "blueprint_refs": [self.ref("blueprint.json", "/")], "topic_adapter_ref": self.ref("adapter.json"),
            "core1a": {"task_id": "TASK-SYNTHETIC-TEACHER", "source_kind": "AUTHORED_NON_EXAM", "artifact": self.ref("teacher.txt")},
            "core1b": {"task_id": "TASK-SYNTHETIC-MAIN", "artifact": self.ref("learner.txt")},
            "roles": [{"id": "r1", "assessment_role": "TARGET", "required_by_core1b": True,
                       "teaching_spans": [self.span("teacher.txt")], "reconstruction_spans": [self.span("learner.txt")]}],
            "bridge_evidence": {f"B{i}": [self.span("teacher.txt"), self.span("learner.txt")] for i in range(1, 8)},
            "runtime": {"compiled_artifacts": [self.ref("compiled.txt", "line:1")], "baseline_artifacts": [self.ref("baseline.txt", "line:1")]}}
        self.bind_reviews()

    def bind_reviews(self):
        spec = self.entry["construction"]
        subject = {"construction": {k: v for k, v in spec.items() if k not in {"review_ref", "runtime_review_ref", "acceptance_review_ref"}},
                   "qrt_subject": self.qrt_subject(), "qrt_decision": self.qrt_decision, "canonical": self.canonical_result}
        decision = {"criteria": {f"B{i}": True for i in range(1, 8)}, "teaching_sufficient": True, "fresh_reconstruction": True,
                    "operation": self.qrt_decision["target"]["operation"], "scores": self.entry["cognitive_seed"]["independent_demand"]["scores"]}
        spec["review_ref"] = self.review("construction-review.json", "construction", subject, decision)
        runtime_subject = {"bound_subject_digest": digest(subject), "bound_decision": decision, "runtime": spec["runtime"]}
        spec["runtime_review_ref"] = self.review("runtime-review.json", "runtime", runtime_subject, {"protected_work": True, "save_before_feedback": True, "content_preserved": True})
        spec["acceptance_review_ref"] = self.review("acceptance-review.json", "acceptance", runtime_subject, {"learner_acceptance": True})
        self.flush()

    def check(self, trusted=False, allow_partial=True):
        checker = Checker(self.folder/"contract.json", self.folder/"registry.json" if trusted else None,
                          file_digest(self.folder/"registry.json") if trusted else None)
        return checker.check(allow_partial)

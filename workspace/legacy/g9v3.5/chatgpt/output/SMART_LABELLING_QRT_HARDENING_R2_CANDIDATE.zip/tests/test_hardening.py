"""Behavioral regressions: targeted gates, reasons, controls and real field layout."""
import copy
import io
import json
import subprocess
import sys
import unittest
import uuid
from pathlib import Path

from fixtures import Fixture, ROOT, digest, file_digest, read, save
from qrt_contract import Checker, FACTORS, GATES, Invalid, read_json


class Hardening(unittest.TestCase):
    def setUp(self):
        folder = (ROOT / "tests/.runs" / uuid.uuid4().hex[:12]).resolve()
        if not folder.is_relative_to(ROOT.resolve()):
            raise RuntimeError("Test output escaped candidate workspace")
        self.f = Fixture(folder)

    def assert_gate(self, report, gate, status, code=None):
        self.assertEqual(report["gate_summary"][gate], status, json.dumps(report, indent=2))
        if code:
            codes = {issue["code"] for issue in report["issues"]}
            codes.update(issue["code"] for r in report["records"] for issue in r["issues"])
            self.assertIn(code, codes)

    def cli(self, gate="integrity", stage=2, trusted=False, extra=()):
        f = self.f
        command = [sys.executable, "-B", "-X", "utf8", "-I", str(ROOT/f"skills/smart-labelling-{stage}/scripts/check_sl{stage}.py"),
                   str(f.folder/f"sl{stage}.json"), "--vocab", str(f.folder/"vocab.json"), "--contract", str(f.folder/"contract.json"), "--gate", gate]
        command += ["--library", str(f.folder/"lib.json")] if stage == 1 else ["--sl1", str(f.folder/"sl1.json")]
        if trusted:
            command += ["--review-registry", str(f.folder/"registry.json"), "--registry-sha256", file_digest(f.folder/"registry.json")]
        command += list(extra)
        proc = subprocess.run(command, capture_output=True, encoding="utf-8", timeout=20)
        self.assertIn(proc.returncode, (0, 1), proc.stderr + proc.stdout)
        return proc.returncode, json.loads(proc.stdout)

    def test_partial_question_integrity_and_no_observation(self):
        report = self.f.check()
        self.assert_gate(report, "integrity", "PASS")
        self.assert_gate(report, "observations", "NOT_APPLICABLE")
        self.assert_gate(report, "official_source", "HOLD")
        self.assert_gate(report, "release", "HOLD")

    def test_partial_practice_requires_caller_policy(self):
        self.assert_gate(self.f.check(allow_partial=False), "practice", "HOLD", "PARTIAL_PRACTICE_POLICY_REQUIRED")
        self.assert_gate(self.f.check(allow_partial=True), "practice", "PASS")

    def test_valid_saved_observation(self):
        self.f.evidence()
        report = self.f.check()
        self.assert_gate(report, "observations", "PASS")
        self.assertEqual(report["records"][0]["observed"]["independence"], "INDEPENDENT")

    def test_explicitly_assisted_observation_is_preserved(self):
        self.f.evidence("HINT")
        report = self.f.check()
        self.assert_gate(report, "observations", "PASS")
        self.assertEqual(report["records"][0]["observed"]["independence"], "ASSISTED")

    def test_unknown_help_is_preserved_without_inference(self):
        self.f.evidence(unknown=True)
        del self.f.attempt["help_before_commit"]
        self.f.save_attempts()
        report = self.f.check()
        self.assert_gate(report, "observations", "PASS")
        self.assertEqual(report["records"][0]["observed"]["independence"], "UNKNOWN")
        code, cli_report = self.cli("observations")
        self.assertEqual(code, 0, cli_report)

    # Four deterministic R1 regressions.
    def test_unsupported_verified_source_claim(self):
        self.f.r1["source_verification"].update(status="VERIFIED", provenance="PYQ_VERIFIED")
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "UNSUPPORTED_VERIFIED_SOURCE")

    def test_source_key_change_without_question_change(self):
        question_digest = self.f.entry["source"]["question_digest"]
        self.f.source["items"][0]["key"] = "B"
        self.f.flush()
        self.assertEqual(self.f.entry["source"]["question_digest"], question_digest)
        report = self.f.check()
        self.assert_gate(report, "answer", "HOLD", "SOURCE_KEY_CHANGED")
        self.assert_gate(report, "integrity", "PASS")
        self.assert_gate(report, "practice", "HOLD")

    def test_saved_answer_contradicts_label(self):
        self.f.evidence()
        self.f.r2["learner"]["original_answer"] = "B"
        self.f.flush()
        self.assert_gate(self.f.check(), "observations", "HOLD", "ATTEMPT_FIELD_MISMATCH")

    def test_verified_key_without_key_custody(self):
        self.f.r2["binding"]["answer_ref_status"] = "KEY_VERIFIED"
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "UNSUPPORTED_VERIFIED_KEY")

    # Ten additional R1 escape cases.
    def test_nonexistent_official_artifacts_and_fake_hashes(self):
        self.f.r1["source_verification"].update(status="VERIFIED", provenance="PYQ_VERIFIED")
        self.f.entry["official_source"] = {"evidence_refs": [{"path": "absent.pdf", "sha256": "garbage", "locator": "page:1"}]}
        self.f.flush()
        report = self.f.check()
        self.assert_gate(report, "official_source", "HOLD", "INVALID_HASH")
        self.assert_gate(report, "integrity", "HOLD", "UNSUPPORTED_VERIFIED_SOURCE")

    def test_wrong_library_hash(self):
        self.f.contract["inputs"]["library"]["sha256"] = "0" * 64
        save(self.f.folder/"contract.json", self.f.contract)
        self.assert_gate(self.f.check(), "integrity", "HOLD", "ARTIFACT_HASH_MISMATCH")

    def test_invented_original_reasoning(self):
        self.f.evidence()
        self.f.r2["learner"]["reasoning"] = "Invented complete proof never present in the saved response."
        self.f.flush()
        report = self.f.check()
        self.assert_gate(report, "observations", "HOLD", "ATTEMPT_FIELD_MISMATCH")
        self.assert_gate(report, "practice", "PASS")

    def test_missing_help_cannot_mean_independent(self):
        self.f.evidence()
        del self.f.attempt["help_before_commit"]
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "HELP_EXPOSURE_MISMATCH")

    def test_duplicate_attempt_ids_cannot_overwrite(self):
        self.f.evidence()
        earlier = copy.deepcopy(self.f.attempt)
        earlier.update(answer="B", help_before_commit="FULL_SOLUTION", committed_before_feedback=False)
        self.f.attempts["attempts"].insert(0, earlier)
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "DUPLICATE_ID")

    def test_fake_key_field_cannot_skip_comparison(self):
        self.f.r1["custody"]["source_key_field"] = "NO_SUCH_FIELD"
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "UNDECLARED_KEY_LOCATOR")

    def test_actual_source_shape_without_key_reports_unsupported(self):
        item = self.f.source["items"][0]
        item.pop("key")
        item["figs"] = {"stem": [], "options": [], "explanation": []}
        item["explanation"] = "Synthetic publisher explanation containing an answer claim."
        self.f.entry["source"]["adapter"] = "examside-json/v1"
        self.f.flush()
        report = self.f.check()
        self.assert_gate(report, "integrity", "PASS")
        self.assert_gate(report, "answer", "HOLD", "ANSWER_FIELD_UNSUPPORTED")

    def test_same_author_review_rejected(self):
        self.f.r1["status"] = "REVIEWED"
        self.f.flush()
        subject = {"record_digest": digest(self.f.r1), "question_digest": self.f.entry["source"]["question_digest"],
                   "answer_digest": self.f.entry["source"]["answer_digest"], "library_sha256": self.f.contract["inputs"]["library"]["sha256"],
                   "vocabulary_sha256": self.f.contract["inputs"]["vocabulary"]["sha256"]}
        ref = self.f.review("self-review.json", "sl1", subject, {})
        review = read(self.f.folder/"self-review.json")
        review["reviewer"] = self.f.s1["labeller"]
        save(self.f.folder/"self-review.json", review)
        self.f.entry["sl1_review_ref"] = self.f.ref("self-review.json")
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "integrity", "HOLD", "REVIEW_NOT_INDEPENDENT")

    def test_stale_sl1_is_never_ready(self):
        self.f.r1["status"] = "STALE"
        self.f.flush()
        report = self.f.check()
        self.assert_gate(report, "integrity", "HOLD", "STALE_RECORD")
        self.assert_gate(report, "practice", "HOLD")

    def test_actual_figs_reference_change_invalidates(self):
        self.f.entry["source"]["adapter"] = "examside-json/v1"
        self.f.source["items"][0]["figs"] = {"stem": [], "options": [], "explanation": []}
        self.f.flush()
        self.f.source["items"][0]["figs"]["stem"] = ["changed.png"]
        self.f.flush(source_digests=False)
        self.assert_gate(self.f.check(), "integrity", "HOLD", "QUESTION_CHANGED")

    def test_missing_essential_figure_asset_blocks(self):
        self.f.entry["source"]["adapter"] = "examside-json/v1"
        self.f.source["items"][0]["figs"] = {"stem": ["missing.png"], "options": [], "explanation": []}
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "FIGURE_ASSET_BINDING")

    def test_figure_free_source_control(self):
        self.f.entry["source"]["adapter"] = "examside-json/v1"
        self.f.source["items"][0]["figs"] = {"stem": [], "options": [], "explanation": []}
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "PASS")

    def test_duplicate_source_ids(self):
        self.f.source["items"].append(copy.deepcopy(self.f.source["items"][0]))
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "DUPLICATE_ID")

    def test_duplicate_json_keys_rejected(self):
        (self.f.folder/"contract.json").write_text('{"schema":"x","schema":"y"}', encoding="utf-8")
        self.assert_gate(self.f.check(), "integrity", "HOLD", "DUPLICATE_JSON_KEY")

    def test_duplicate_contract_ids(self):
        self.f.contract["records"].append(copy.deepcopy(self.f.entry))
        save(self.f.folder/"contract.json", self.f.contract)
        self.assert_gate(self.f.check(), "integrity", "HOLD", "DUPLICATE_ID")

    def test_missing_contract_record_is_coverage_gap(self):
        self.f.contract["records"] = []
        save(self.f.folder/"contract.json", self.f.contract)
        self.assert_gate(self.f.check(), "integrity", "HOLD", "COVERAGE_RECONCILIATION")

    def test_malformed_nested_attempt_type_has_explicit_diagnostic(self):
        self.f.evidence()
        self.f.attempts["attempts"] = "not-an-array"
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "INVALID_TYPE")

    def test_commit_without_save_is_not_saved_evidence(self):
        self.f.evidence()
        self.f.attempt["saved"] = False
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "ATTEMPT_NOT_SAVED")

    def test_event_order_contradicts_independence(self):
        self.f.evidence()
        self.f.attempt["feedback_sequence"] = 1
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "SAVE_ORDER_CONTRADICTION")

    def test_later_saved_attempt_is_not_first(self):
        self.f.evidence()
        earlier = copy.deepcopy(self.f.attempt)
        earlier.update(attempt_id="A0", save_sequence=1)
        self.f.attempts["attempts"].insert(0, earlier)
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "NOT_FIRST_SAVED_ATTEMPT")

    def test_core1b_cannot_be_relabelled_p1(self):
        self.f.evidence()
        self.f.attempt["stage"] = "CORE1B"
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "OBSERVATION_STAGE_UNSUPPORTED")

    def test_changed_question_version_invalidates_attempt(self):
        self.f.evidence()
        self.f.attempt["question_version"] += 1
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "ATTEMPT_BINDING_MISMATCH")

    def test_correctness_claim_needs_interpretation_review(self):
        self.f.evidence()
        self.f.r2["learner"]["result"] = "CORRECT"
        self.f.flush()
        self.assert_gate(self.f.check(), "observations", "HOLD", "TRUST_REGISTRY_REQUIRED")

    def test_generic_long_crux_cannot_qualify_qrt(self):
        self.assert_gate(self.f.check(), "qrt", "HOLD", "TRUST_REGISTRY_REQUIRED")

    def test_seed_distributed_decisive_roles_allowed(self):
        role = copy.deepcopy(self.f.entry["cognitive_seed"]["decisive_roles"][0])
        role["id"] = "r2"
        self.f.entry["cognitive_seed"]["decisive_roles"].append(role)
        self.f.qrt()
        self.assert_gate(self.f.check(trusted=True), "qrt", "PASS")

    def test_same_total_factor_change_needs_disagreement(self):
        scores = dict(self.f.entry["cognitive_seed"]["independent_demand"]["scores"])
        keys = list(FACTORS)
        scores[keys[0]], scores[keys[1]] = scores[keys[1]], scores[keys[0]]
        self.f.entry["cognitive_seed"]["independent_demand"]["prior_comparison"] = {"scores": scores, "differences": ""}
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "MISSING_VALUE")

    def test_direct_exam_role_requires_custody(self):
        self.f.qrt("DIRECT_EXAM_EVIDENCE")
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "EXAM_CUSTODY_HOLD")

    def test_cross_operation_bridge_is_allowed(self):
        self.f.qrt(operation="APPLY", target_operation="JUSTIFY")
        report = self.f.check(trusted=True)
        self.assert_gate(report, "qrt", "PASS")
        self.assertEqual(report["records"][0]["qrt_decision"]["operation"], "APPLY")

    def test_direct_exam_operation_cannot_change_at_target(self):
        self.f.official()
        self.f.qrt("DIRECT_EXAM_EVIDENCE", operation="APPLY")
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "DIRECT_SOURCE_TARGET_MISMATCH")

    def test_trusted_source_and_key_control(self):
        self.f.official()
        report = self.f.check(trusted=True)
        self.assert_gate(report, "official_source", "PASS")
        self.assert_gate(report, "official_key", "PASS")
        self.assert_gate(report, "practice", "PASS")

    def test_paper_review_does_not_qualify_key(self):
        self.f.official()
        del self.f.entry["official_key"]
        self.f.flush()
        report = self.f.check(trusted=True)
        self.assert_gate(report, "official_source", "PASS")
        self.assert_gate(report, "official_key", "HOLD")

    def test_review_registry_must_be_independently_pinned(self):
        self.f.official()
        report = Checker(self.f.folder/"contract.json", self.f.folder/"registry.json", "0"*64).check(True)
        self.assert_gate(report, "official_source", "HOLD", "TRUST_PIN_MISMATCH")
        self.assert_gate(report, "practice", "PASS")

    def test_withdrawn_reviewer_invalidates_qualification(self):
        self.f.official()
        registry = read(self.f.folder/"registry.json")
        registry["reviewers"][0]["status"] = "WITHDRAWN"
        save(self.f.folder/"registry.json", registry)
        self.assert_gate(self.f.check(trusted=True), "official_source", "HOLD", "REVIEWER_NOT_AUTHORIZED")

    def test_copied_review_of_changed_record_is_stale(self):
        self.f.qrt()
        self.f.entry["cognitive_seed"]["conditions"].append({"condition": "new assumption"})
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "REVIEW_SUBJECT_CHANGED")

    def test_candidate_library_bytes_do_not_qualify_warrant(self):
        self.assert_gate(self.f.check(trusted=True), "canonical", "HOLD")

    def test_full_synthetic_contract_control(self):
        self.f.official()
        self.f.qrt()
        self.f.bound()
        report = self.f.check(trusted=True)
        for gate in GATES:
            self.assert_gate(report, gate, "NOT_APPLICABLE" if gate == "observations" else "PASS")
        code, cli_report = self.cli("release", trusted=True)
        self.assertEqual(code, 0, cli_report)

    def test_bound_task_cannot_reuse_exam_identity(self):
        self.f.qrt()
        self.f.bound()
        self.f.entry["construction"]["task_id"] = self.f.qid
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "BOUND_TASK_IDENTITY_CONFLATED")

    def test_required_reconstruction_role_must_be_taught(self):
        self.f.qrt()
        self.f.bound()
        self.f.entry["construction"]["roles"][0]["teaching_spans"] = []
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "BRIDGE_ROLE_NOT_TAUGHT_OR_ELICITED")

    def test_teacher_target_role_must_be_assessed(self):
        self.f.qrt()
        self.f.bound()
        self.f.entry["construction"]["roles"][0]["required_by_core1b"] = False
        self.f.entry["construction"]["roles"][0]["reconstruction_spans"] = []
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "BRIDGE_ROLE_NOT_TAUGHT_OR_ELICITED")

    def test_changed_rendered_passage_invalidates_binder(self):
        self.f.qrt()
        self.f.bound()
        (self.f.folder/"teacher.txt").write_text("Different passage.\n", encoding="utf-8")
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "ARTIFACT_HASH_MISMATCH")

    def test_absent_b7_evidence_blocks_construction(self):
        self.f.qrt()
        self.f.bound()
        del self.f.entry["construction"]["bridge_evidence"]["B7"]
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "BRIDGE_WITNESS_INCOMPLETE")

    def test_missing_runtime_does_not_undo_binder_qualification(self):
        self.f.qrt()
        self.f.bound()
        del self.f.entry["construction"]["runtime_review_ref"]
        self.f.flush()
        report = self.f.check(trusted=True)
        self.assert_gate(report, "construction", "PASS")
        self.assert_gate(report, "release", "HOLD")

    def test_missing_learner_acceptance_blocks_release(self):
        self.f.qrt()
        self.f.bound()
        del self.f.entry["construction"]["acceptance_review_ref"]
        self.f.flush()
        report = self.f.check(trusted=True)
        self.assert_gate(report, "construction", "PASS")
        self.assert_gate(report, "release", "HOLD")

    def test_cli_sl1_retains_legacy_content_checks(self):
        code, report = self.cli("practice", stage=1, extra=("--allow-partial-practice",))
        self.assertEqual(code, 0, report)
        self.assertTrue(all(check["exit_code"] == 0 for check in report["legacy_checks"]))
        self.f.r1["learner_card"]["hints"] = "The correct option is A"
        self.f.flush()
        code, report = self.cli("practice", stage=1, extra=("--allow-partial-practice",))
        self.assertEqual(code, 1)
        self.assertIn("LEGACY_RULES_FAILED", {x["code"] for x in report["issues"]})

    def test_cli_runs_without_writing_source_inputs(self):
        before = {p.name: file_digest(p) for p in self.f.folder.iterdir() if p.is_file()}
        code, report = self.cli()
        self.assertEqual(code, 0, report)
        after = {p.name: file_digest(p) for p in self.f.folder.iterdir() if p.is_file()}
        self.assertEqual(before, after)

    def test_self_contained_skill_modules_match(self):
        for name in ("qrt_contract.py", "qrt_cli.py", "prepare_contract.py", "legacy_check_sl1.py", "legacy_check_sl2.py", "digest.py"):
            self.assertEqual((ROOT/f"skills/smart-labelling-1/scripts/{name}").read_bytes(), (ROOT/f"skills/smart-labelling-2/scripts/{name}").read_bytes())

    def test_blank_condition_is_not_typed_evidence(self):
        self.f.entry["cognitive_seed"]["conditions"] = [{}]
        self.f.qrt()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "MISSING_VALUE")

    def test_seed_pointer_must_resolve_actual_source(self):
        self.f.entry["cognitive_seed"]["inputs"][0]["source_pointer"] = "/nonexistent"
        self.f.qrt()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "POINTER_NOT_FOUND")

    def test_seed_cannot_self_qualify_physics(self):
        self.f.entry["cognitive_seed"]["dependencies"][0]["authority_status"] = "QUALIFIED"
        self.f.qrt()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "SEED_AUTHORITY_OWNERSHIP")

    def test_raw_false_help_cannot_be_independent(self):
        self.f.evidence()
        self.f.attempt["help_before_commit"] = False
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "HELP_HISTORY_UNKNOWN")

    def test_feedback_absence_must_be_explicit(self):
        self.f.evidence()
        del self.f.attempt["feedback_sequence"]
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "HOLD", "SAVE_ORDER_UNKNOWN")

    def test_older_version_does_not_steal_first_attempt(self):
        self.f.evidence()
        earlier = copy.deepcopy(self.f.attempt)
        earlier.update(attempt_id="A0", save_sequence=1, question_version=0)
        self.f.attempts["attempts"].insert(0, earlier)
        self.f.save_attempts()
        self.assert_gate(self.f.check(), "observations", "PASS")

    def test_missing_file_with_valid_hash_shape_is_rejected(self):
        self.f.entry["official_source"] = {"evidence_refs": [{"path": "absent.pdf", "sha256": "0"*64, "locator": "page:1"}]}
        self.f.flush()
        self.assert_gate(self.f.check(), "official_source", "HOLD", "ARTIFACT_MISSING")

    def test_library_duplicate_id_cannot_shadow_an_entry(self):
        lib = read(self.f.folder/"lib.json")
        lib["microtopics"].append(copy.deepcopy(lib["microtopics"][0]))
        save(self.f.folder/"lib.json", lib)
        self.f.s1["library_ref"].pop("sha256", None)
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "DUPLICATE_ID")

    def test_declared_library_cannot_point_elsewhere(self):
        self.f.s1["library_ref"]["path"] = str(self.f.folder/"other-library.json")
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "DECLARED_DEPENDENCY_MISMATCH")

    def test_source_paper_identity_must_match(self):
        self.f.source["items"][0]["paper"] = "Different synthetic paper"
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "SOURCE_PAPER_MISMATCH")

    def test_adapter_cannot_ignore_actual_figs(self):
        self.f.source["items"][0]["figs"] = {"stem": ["hidden.png"]}
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "ADAPTER_SOURCE_SHAPE_MISMATCH")

    def test_bound_source_relationship_cannot_change(self):
        self.f.qrt()
        self.f.bound()
        self.f.entry["construction"]["source_question_id"] = "OTHER-QUESTION"
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "BOUND_SOURCE_RELATIONSHIP_MISMATCH")

    def test_missing_teacher_task_id_is_not_freshness(self):
        self.f.qrt()
        self.f.bound()
        del self.f.entry["construction"]["core1a"]["task_id"]
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "MISSING_VALUE")

    def test_reviewed_answer_extraction_control(self):
        item = self.f.source["items"][0]
        del item["key"]
        item["explanation"] = "Synthetic explanation whose reviewed extraction says A."
        self.f.flush()
        extraction = {"schema": "smart-labelling-answer-extraction/v2", "source_item_id": item["id"],
                      "source_answer_digest": self.f.entry["source"]["answer_digest"], "answer": "A", "author": "synthetic"}
        save(self.f.folder/"extraction.json", extraction)
        self.f.entry["answer_reference"] = {"kind": "REVIEWED_EXTRACTION", "value": "A", "artifact": self.f.ref("extraction.json"),
             "review_ref": self.f.review("extraction-review.json", "answer_extraction", extraction, {"answer": "A"})}
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "answer", "PASS")
        item["explanation"] += " Changed."
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "answer", "HOLD", "EXTRACTION_STALE")

    def test_interpretation_is_bound_to_resolved_answer(self):
        self.f.evidence()
        self.f.r2["learner"]["result"] = "CORRECT"
        self.f.flush()
        answer_digest = digest({"source_answer_digest": self.f.entry["source"]["answer_digest"], "answer_reference": self.f.entry["answer_reference"],
                                "sl1_answer_check": self.f.r1["content_integrity"]["answer_check"]})
        interpretation = {k: self.f.r2["learner"].get(k) for k in ("result", "prerequisite_state", "failure_hypothesis")}
        subject = {"attempt_digest": digest(self.f.attempt), "answer_digest": answer_digest, "interpretation": interpretation}
        self.f.entry["observation"]["interpretation_review_ref"] = self.f.review("interpretation-review.json", "learner_interpretation", subject, {"interpretation": interpretation})
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "observations", "PASS")
        self.f.source["items"][0]["key"] = "B"
        self.f.r1["content_integrity"]["answer_check"]["key"] = "B"
        self.f.entry["answer_reference"]["value"] = "B"
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "observations", "HOLD", "REVIEW_SUBJECT_CHANGED")

    def test_correctness_cannot_use_unresolved_answer(self):
        self.f.evidence()
        self.f.r2["learner"]["result"] = "CORRECT"
        self.f.entry["answer_reference"] = {"kind": "UNRESOLVED"}
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "observations", "HOLD", "INTERPRETATION_ANSWER_UNRESOLVED")

    def test_snapshot_preparer_does_not_invent_reviews(self):
        from prepare_contract import prepare
        before = file_digest(self.f.folder/"sl1.json")
        contract = prepare(self.f.folder/"sl1.json", self.f.folder/"lib.json", self.f.folder/"vocab.json", "explicit-key-json/v1", self.f.folder/"sl2.json")
        self.assertEqual(contract["preparation_status"], "UNREVIEWED_SNAPSHOT_ONLY")
        self.assertIsNone(contract["records"][0]["cognitive_seed"])
        self.assertNotIn("qrt_review_ref", contract["records"][0])
        self.assertEqual(before, file_digest(self.f.folder/"sl1.json"))

    def test_snapshot_preparer_preserves_unsupported_explanation_key(self):
        from prepare_contract import prepare
        item = self.f.source["items"][0]
        del item["key"]
        item["explanation"] = "Synthetic publisher solution"
        item["figs"] = {"stem": [], "options": [], "explanation": []}
        self.f.flush()
        contract = prepare(self.f.folder/"sl1.json", self.f.folder/"lib.json", self.f.folder/"vocab.json", "examside-json/v1", self.f.folder/"sl2.json")
        self.assertEqual(contract["records"][0]["answer_reference"]["kind"], "UNRESOLVED")

    def test_snapshot_preparer_never_overwrites(self):
        destination = self.f.folder/"contract.json"
        before = file_digest(destination)
        proc = subprocess.run([sys.executable, "-B", "-I", str(ROOT/"skills/smart-labelling-1/scripts/prepare_contract.py"), str(self.f.folder/"sl1.json"),
                               "--library", str(self.f.folder/"lib.json"), "--vocab", str(self.f.folder/"vocab.json"), "--adapter", "explicit-key-json/v1", "--out", str(destination)],
                              capture_output=True, text=True, timeout=20)
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(before, file_digest(destination))

    def test_missing_contract_does_not_silently_fall_back(self):
        proc = subprocess.run([sys.executable, "-B", "-I", str(ROOT/"skills/smart-labelling-1/scripts/check_sl1.py"), str(self.f.folder/"sl1.json"),
                               "--library", str(self.f.folder/"lib.json"), "--vocab", str(self.f.folder/"vocab.json")], capture_output=True, text=True, timeout=20)
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(json.loads(proc.stdout)["issues"][0]["code"], "CONTRACT_REQUIRED")

    def test_first_score_flag_alone_is_insufficient(self):
        self.f.qrt()
        review = read(self.f.folder/"qrt-review.json")
        del review["decision"]["first_assessment_ref"]
        save(self.f.folder/"qrt-review.json", review)
        self.f.entry["qrt_review_ref"] = self.f.ref("qrt-review.json")
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "INVALID_TYPE")

    def test_first_assessment_must_precede_comparison(self):
        self.f.qrt()
        first = read(self.f.folder/"first-assessment.json")
        first["saved_sequence"] = 3
        save(self.f.folder/"first-assessment.json", first)
        review = read(self.f.folder/"qrt-review.json")
        review["decision"]["first_assessment_ref"] = self.f.ref("first-assessment.json")
        save(self.f.folder/"qrt-review.json", review)
        self.f.entry["qrt_review_ref"] = self.f.ref("qrt-review.json")
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "FIRST_ASSESSMENT_ORDER_UNKNOWN")

    def test_option_mapping_must_cover_the_official_answer(self):
        self.f.official()
        review = read(self.f.folder/"key-review.json")
        review["decision"]["option_mapping"]["official_to_source"] = {"B": "B"}
        save(self.f.folder/"key-review.json", review)
        self.f.entry["official_key"]["review_ref"] = self.f.ref("key-review.json")
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "official_key", "HOLD", "KEY_OPTION_MAPPING_MISMATCH")

    def test_saved_equal_total_prior_cannot_be_omitted(self):
        self.f.r2["difficulty_evidence"]["prior_proposal"] = {"source": "synthetic prior", "scores": "1/2/2/1/0", "total": 6}
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "PRIOR_COMPARISON_MISSING")

    def test_saved_prior_vector_must_match_the_actual_prior(self):
        prior = {"source": "synthetic prior", "scores": "1/2/2/1/0", "total": 6}
        self.f.r2["difficulty_evidence"]["prior_proposal"] = prior
        self.f.entry["cognitive_seed"]["independent_demand"]["prior_comparison"] = {
            "proposal_digest": digest(prior), "scores": dict(self.f.entry["cognitive_seed"]["independent_demand"]["scores"]), "differences": "none"}
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "PRIOR_VECTOR_MISMATCH")

    def test_changed_blueprint_blocks_construction_only(self):
        self.f.qrt()
        self.f.bound()
        save(self.f.folder/"blueprint.json", {"schema": "synthetic-blueprint", "version": "changed"})
        report = self.f.check(trusted=True)
        self.assert_gate(report, "qrt", "PASS")
        self.assert_gate(report, "construction", "HOLD", "ARTIFACT_HASH_MISMATCH")

    def test_negative_array_index_is_not_a_json_pointer(self):
        from qrt_contract import pointer_value
        with self.assertRaises(Invalid) as caught:
            pointer_value({"items": ["a"]}, "/items/-1")
        self.assertEqual(caught.exception.code, "INVALID_POINTER")

    def test_anchor_source_adapter_binds_text_and_answer(self):
        from qrt_contract import source_payloads
        item = {"id": "AN-SYNTHETIC", "text": "Synthetic anchor text", "options": {"A": "Synthetic option"},
                "answer": "A", "answer_basis": "Synthetic working", "format": "single_correct_mcq"}
        save(self.f.folder/"anchor.json", {"items": [item]})
        normalized, question, answer = source_payloads(self.f.folder/"anchor.json", "anchors-json/v1", item["id"])
        self.assertEqual(normalized["stem"], item["text"])
        self.assertEqual(normalized["key"], "A")
        previous = digest(question)
        item["answer"] = "B"
        save(self.f.folder/"anchor.json", {"items": [item]})
        _, next_question, next_answer = source_payloads(self.f.folder/"anchor.json", "anchors-json/v1", item["id"])
        self.assertEqual(previous, digest(next_question))
        self.assertNotEqual(digest(answer), digest(next_answer))

    def test_anchor_adapter_cannot_ignore_a_figure_or_conflicting_stem(self):
        from qrt_contract import source_payloads
        save(self.f.folder/"anchor.json", {"items": [{"id": "AN-SYNTHETIC", "text": "Synthetic anchor", "options": {}, "stem": "Conflicting source"}]})
        with self.assertRaises(Invalid) as caught:
            source_payloads(self.f.folder/"anchor.json", "anchors-json/v1", "AN-SYNTHETIC")
        self.assertEqual(caught.exception.code, "ADAPTER_SOURCE_SHAPE_MISMATCH")

    def test_declared_per_item_adapter_overrides_default(self):
        from prepare_contract import prepare
        self.f.source["items"][0]["figs"] = {"stem": [], "options": [], "explanation": []}
        self.f.flush()
        contract = prepare(self.f.folder/"sl1.json", self.f.folder/"lib.json", self.f.folder/"vocab.json", "explicit-key-json/v1",
                           self.f.folder/"sl2.json", adapter_map={self.f.qid: "examside-json/v1"})
        self.assertEqual(contract["preparation_issues"], [])
        self.assertEqual(contract["records"][0]["source"]["adapter"], "examside-json/v1")

    def test_essential_figure_cannot_be_just_a_validated_note(self):
        self.f.r1["format"]["figure"] = "ESSENTIAL"
        self.f.r1["content_integrity"]["figure_validated"] = "VALIDATED"
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "ESSENTIAL_FIGURE_NOT_BOUND")

    def test_malformed_adapter_map_reports_unsupported(self):
        from prepare_contract import prepare
        contract = prepare(self.f.folder/"sl1.json", self.f.folder/"lib.json", self.f.folder/"vocab.json", None,
                           self.f.folder/"sl2.json", adapter_map={self.f.qid: {"field": "key"}})
        self.assertEqual(contract["preparation_issues"][0]["code"], "UNSUPPORTED_ADAPTER")

    def test_changed_library_semantics_invalidates_qrt_review(self):
        self.f.qrt()
        library = read(self.f.folder/"lib.json")
        library["qualification_status"] = "CHANGED"
        save(self.f.folder/"lib.json", library)
        self.f.s1["library_ref"].pop("sha256", None)
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "qrt", "HOLD", "REVIEW_SUBJECT_CHANGED")

    def test_teacher_cannot_reuse_exam_task_identity(self):
        self.f.qrt()
        self.f.bound()
        self.f.entry["construction"]["core1a"]["task_id"] = self.f.qid
        self.f.flush()
        self.assert_gate(self.f.check(trusted=True), "construction", "HOLD", "TEACHER_SOURCE_NOT_DISTINCT")

    def test_changed_rubric_boundaries_do_not_inherit_old_policy(self):
        vocab = read(self.f.folder/"vocab.json")
        vocab["question_difficulty_score_ranges"]["D3"]["min"] = 7
        save(self.f.folder/"vocab.json", vocab)
        self.f.flush()
        self.assert_gate(self.f.check(), "integrity", "HOLD", "RUBRIC_POLICY_UNSUPPORTED")


if __name__ == "__main__":
    class RecordedResult(unittest.TextTestResult):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.cases = []

        def addSuccess(self, test):
            super().addSuccess(test)
            self.cases.append({"test": test._testMethodName, "status": "PASS"})

        def addFailure(self, test, err):
            super().addFailure(test, err)
            self.cases.append({"test": test._testMethodName, "status": "FAIL"})

        def addError(self, test, err):
            super().addError(test, err)
            self.cases.append({"test": test._testMethodName, "status": "ERROR"})

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Hardening)
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=RecordedResult).run(suite)
    (ROOT/"review/R2_TEST_LOG.txt").write_text(log.getvalue(), encoding="utf-8")
    report = {"scope": "Author-side synthetic deterministic regression; no academic or learner acceptance", "tests_run": result.testsRun,
              "failures": [{"test": str(test), "trace": trace} for test, trace in result.failures],
              "errors": [{"test": str(test), "trace": trace} for test, trace in result.errors], "passed": result.wasSuccessful(), "cases": result.cases}
    save(ROOT/"review/R2_REGRESSION_RESULTS.json", report)
    print(json.dumps({"tests_run": result.testsRun, "passed": result.wasSuccessful(), "failures": len(result.failures), "errors": len(result.errors)}))
    if not result.wasSuccessful():
        print(log.getvalue())
    raise SystemExit(0 if result.wasSuccessful() else 1)

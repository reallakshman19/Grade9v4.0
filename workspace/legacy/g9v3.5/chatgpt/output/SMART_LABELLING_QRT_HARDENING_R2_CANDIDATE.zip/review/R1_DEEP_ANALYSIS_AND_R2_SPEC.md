# Smart Labelling R1: source-grounded review and next candidate specification

30 October 2026. Decision: **agree with the architecture; retain PARTIAL for implementation; do not use R1 as a qualification gate yet.**

The Owner asked this Oracle to step back and deeply assess the supplied R1 proposal before continuing candidate authoring. This report reviews that proposal and its executable behavior. It does not resume D3.1 finalisation, install skills, accept Physics, change the Blueprint, or release learning pages. I had already inspected the original skills and had begun an isolated candidate workspace. I authored the additional probes and this specification; their results are author-side reproductions, not a separate academic certification.

## What I agree with

The proposed responsibility split is right. SL1 establishes source identity, question integrity, mapping and first-try fitness. SL2 describes the intellectual requirement and, only when it exists, the actual observation of learner work. QRT adjudicates operation, intrinsic demand and source relationship. The construction binder subsequently establishes qualified warrants and teaching-to-reconstruction correspondence. The compiler preserves that construction and implements disclosure and save states.

These are distinct claims. A question can be usable for honestly labelled practice while its official examination custody remains unverified. Its answer can agree with a publisher without its key being official. Its source classification can be APPLY while an explicitly authored JUSTIFY task uses its Physics as a bridge. A well-formed SL2 record cannot establish that a future Core1A lesson adequately teaches Core1B.

SL3 is unnecessary. A versioned, derived SL2-to-QRT handoff is appropriate. It must remain a candidate statement of the required intellectual work, with unresolved authority visible. It must not become a miniature topic adapter, a lesson authoring system, or an owner of physical truth.

I would also narrow my own earlier implementation direction: a full construction graph, qualified per-step teaching warrants and completed B1–B7 witness should not all become mandatory SL2 outputs. SL2 needs enough typed evidence for QRT to inspect the requirement. The complete instructional witness belongs downstream, where the actual teacher and learner passages exist.

## What was actually verified

The received ZIP is `C:/Users/reall/Downloads/SMART_LABELLING_QRT_HARDENING_R1.zip`, SHA-256 `44552fe21a22e3f60e1f0e118be556f2d5d9d6e15ba11519131762eae0bb8c82`. All 26 members passed ZIP CRC checking. All 25 manifest-listed files matched their hashes. The seven packaged original skill files match the seven current local originals byte for byte. The package's claim about the separate, original `skills.zip` hash was not independently checked because that archive was not supplied here.

The package was extracted into this review directory with traversal, absolute-path and symlink checks. Its inspected tests were executed only in that isolated copy. The supplied tests reproduced four targeted rejection cases. Separately, `probe_r1.py` exercised ten additional negative cases and two positive controls against R1 strict mode together with the original checkers. All ten negative cases returned no R1 issues and zero exits from the applicable original checkers; both positive controls passed. See `R1_ADVERSARIAL_RESULTS.json` for exact cases and per-checker output, and `R1_INTAKE_RECEIPT.json` for intake evidence.

These results expose missing requirements and bypasses in a deliberately limited prototype. They do not contradict R1's explicit warning that it is supplementary and cannot authenticate documents or judge cognitive semantics. They do contradict treating its current green result as a robust qualification gate.

## Four claims need tightening

**1. There are four demonstrated deterministic false passes, plus a semantic limitation/control—not five independently established false passes.** The fifth row is literally named `SL2 QUESTION baseline`. It contains generic evidence sentences but no independently established correct operation/score against which a wrong verdict was demonstrated. Acceptance of that row proves that the checker does not judge semantic adequacy; it does not independently prove that its proposed JUSTIFY/D3 label is false. Keep the semantic limitation, correct the numerical claim.

**2. The original system already has a key-value hash in SL2.** Its missing link is freshness and provenance against the current source/official artifact, rather than the complete absence of a key digest. A changed source key can escape SL1's question-payload digest while SL2 remains bound to an unchanged, stale copied key. Strengthen that source-to-SL1-to-SL2 chain rather than add another unconnected hash.

**3. Presence is weaker than verifiable reference integrity.** R1 tests whether `evidence_refs`, `key_evidence_refs`, `review_attestation` and a library hash are truthy. It does not verify their content, file existence, byte identity, exact source-item correspondence, or reviewer independence. Document authenticity still requires custody review even after those deterministic checks are added.

**4. M101 and the cut-spring MAIN are different bound tasks.** The actual Owner-local `qrt/sources/examside-wpe-extract.json` identifies M101 as AIEEE 2012. Its stem compares two springs with force constants under equal-force and equal-extension conditions. It contains no cutting, spring-length calculation, or uniform-spring length-to-stiffness premise. The R1 example attaches a uniform-spring/length warrant and a cut-spring teaching requirement to M101's source identity. Those belong to the separately bound teaching/MAIN construction described in the concept note. A shared controlled-comparison family does not make their complete task signatures identical. M101's primary operation and demand remain for actual QRT adjudication; statement/MCQ format alone settles neither.

## Additional executable findings

All cases below were run in strict mode, with readable local synthetic files and with the applicable original checkers as well. “Accepted” means those programs returned no issue/nonzero exit. It does not mean a human reviewer accepted the claim.

| Case that a robust gate should reject or hold | R1 plus original checkers | Missing control |
| --- | --- | --- |
| Nonexistent official paper and key, each with a fabricated hash | Accepted | Resolve referenced artifact, verify hash, bind paper/question/option/key identities; then require custody review |
| Existing library file but deliberately wrong 64-digit hash | Accepted | Recompute and compare exact bytes, rather than test that a hash string exists |
| Learner reasoning replaced by an invented derivation | Accepted | Preserve and compare original reasoning; store interpretation separately |
| Missing help history labelled INDEPENDENT | Accepted | UNKNOWN is not NONE; require positive evidence of pre-commit exposure state |
| Duplicate attempt ID, with a later row overwriting an assisted earlier row | Accepted | Reject duplicate IDs before constructing a lookup; identify the actual first saved observation |
| Changed source key hidden by setting `source_key_field` to a nonexistent field | Accepted | Validate source adapter/key locator; missing expected field must be HOLD/error |
| Source has only a publisher explanation, with no explicit key field | Accepted | Report unsupported answer-reference extraction, rather than imply it was compared |
| REVIEWED with the labeller named as its own reviewer | Accepted | Check the review subject, exact reviewed digest, evidence and distinct actor under actual trusted review custody |
| STALE SL1 record still READY_FOR_FIRST_TRY | Accepted | Separate archival readability from fitness/export gates; stale cannot remain ready |
| Figure references change under actual `figs` field while default digest remains unchanged | Accepted | Bind actual figure references and asset hashes, with a versioned serialization/source adapter |

The first two failures are not failures to solve the difficult problem of proving authenticity. Detecting a nonexistent referenced file or a wrong digest is an ordinary deterministic integrity obligation. R1 does not yet implement it. The invented-reasoning failure also matters beyond copying an answer: corrupting the observed reasoning can manufacture the apparent cognitive evidence on which QRT diagnosis relies.

R1 treats absent, null, empty and false help values as no help. Legacy records with incomplete exposure history should instead remain UNKNOWN. A true commit flag alone does not establish a successful save before feedback. A stored observation can support consistency checking, but a mutable JSON file cannot prove its own historical immutability merely because a hash is added today.

Duplicate source IDs, duplicate attempt IDs, malformed nested types and duplicate JSON keys need explicit diagnostics. These checks protect against ambiguous interpretation; they do not establish the truth of a Physics argument.

## The actual WPE source requires adapters, not fixture-specific assumptions

The inspected real M84 and M101 objects have fields `id`, `url`, `paper`, `type`, `stem`, `options`, `explanation`, and `figs`. They have neither an explicit `key` field nor `figure_note`. R1's synthetic source has both `key` and `figure_note`.

Consequently, a negative test on the synthetic key field does not show that R1 detects answer changes in the actual WPE source. The default legacy question digest also does not bind the real `figs` arrays. Where an answer is only conveyed in explanation prose, define an explicit extraction/review artifact with a digest and provenance. Do not infer that a missing key field means its freshness was verified. Separate publisher explanation, publisher answer, official answer-key row, and independent working.

Source adapters should be small and declared: extracted question-bank JSON, official-paper/key artifacts, textbook items, and authored variants. Every adapter must report what it successfully resolved and what remains unsupported. A missing figure may be NOT_APPLICABLE for a genuinely figure-free question; an essential missing figure is HOLD. An absent key may be NO_KEY; it cannot silently become a verified key.

## Strengthen the contract without moving ownership

Use three linked identities: **source question**, **reviewed cognitive requirement**, and **bound teaching/assessment task**. Also keep construction-family identity separate from each concrete task. An authored transfer receives a distinct task/question identity and an explicit derivation relationship. It does not inherit the examination identity, official key or demand of its source.

A minimal SL2 seed should identify inputs and requested output, the candidate decisive role or linked set of roles, relevant route/dependency references, governing conditions and unmet authority requirements, boundary/countercase, independent check, wrong-move hypotheses and competing operation explanations. Keep the existing operation IDs: RETRIEVE and REPRESENT can display as Recall/Classify and Translate. Do not introduce new columns through vocabulary aliases.

Do not require all seven operations to have the same proof-chain shape, or force a distributed SYNTHESIZE bottleneck into one isolated atomic move. TRANSLATE needs correspondences/invariants; CLASSIFY needs criteria and exclusion; JUSTIFY needs claim/warrant/scope; SYNTHESIZE needs dependency and traversal evidence. These are typed interpretations of the shared traceability contract, not seven new sidecar schemas.

SL2 proposes the source operation and five factors independently of teaching hints and existing builder scores. Compare earlier proposals only after that initial assessment. Preserve disagreement even when changed factor vectors happen to have the same sum. QRT's adjudication then records the resolved operation, demand, source role and rationale against the exact SL2 evidence version. Neither a hidden hint nor the number of cases manufactures D3/D4.

For DIRECT_EXAM_EVIDENCE, the reviewed source operation/demand must actually support the target claim. For PREREQUISITE_BRIDGE, the source can have a different decisive operation; require an explicit relationship, not a false source–teacher–learner equivalence. AUTHORED_TRANSFER is a separate task. Unresolved sources remain visible on HOLD. Assign one primary coverage home after adjudication, with secondary references that do not multiply examination coverage.

The binder must eventually demonstrate actual Core1A sufficiency, fresh corresponding Core1B work, protected roles, diagnosis, repair and transfer through B1–B7. A seed containing a future teaching requirement is not a completed Bridge Witness. Evidence of the actual rendered teacher/learner spans and independent semantic judgment remain necessary.

## An implementable R2 scope

**First deliverable: declared source adapters and current dependency binding.** Preserve legacy schemas and digests; add a versioned sidecar/candidate migration rather than silently change hash meaning. Keep exact raw artifact hashes for custody and canonical, versioned per-item digests for incremental invalidation. Bind question payload, figure assets, answer reference and qualification status separately. Compare actual bytes and source-item/key/option mapping. A format-only file change can require custody readback without necessarily invalidating every question's intellectual classification.

**Second deliverable: truthful observation binding.** Require a readable, unique saved attempt in EVIDENCE mode. Verify question/task version, observation stage, answer, original reasoning, confidence, exposure history and commit/save sequence. Preserve unknowns. Keep interpreted result, diagnosed move and capability inference as derived claims with evidence, rather than pretend they were raw observations. P1 remains optional: QUESTION mode must remain valid without it. A future Core1B attempt must not be mislabeled as a pre-teaching P1 attempt.

**Third deliverable: versioned QRT handoff.** Add the compact seed and independent-review/disagreement record, pinning the input evidence and actual reviewer record. Do not fill unresolved M101 fields with JUSTIFY/D3 merely because the workstream wants JUSTIFY evidence. Generate separate binder requirements only after QRT determines the source relationship. Human review cannot be replaced by a reviewer-name string; full public-key infrastructure is not a prerequisite if trusted Owner-local review custody already exists.

**Fourth deliverable: downstream invalidation and staged gates.** Compute stale/blocked state from changed inputs; do not depend on a person remembering to type STALE. Maintain a dependency map from source/question/key through SL1, SL2, QRT decision and bound construction to affected packs/pages. Invalidate claims selectively: a publisher-key change invalidates answer evaluation; it need not change an unchanged original stem. Changed authority or rubric can invalidate qualification even when the answer value stays the same.

Use separate outputs for record integrity, practice fitness, official source/key custody, QRT adjudication, canonical authority, construction readiness and release. Fail closed at the affected promotion boundary. Missing official custody need not stop local ingestion or an honestly labelled prototype; missing P1 must not stop learning; unqualified Physics must not be promoted as accepted teaching. Avoid one boolean that either blocks all useful work or falsely accepts every stage.

## Regression and admission criteria

The R1 test runner checks that expected codes are a subset of returned codes. It has no clean positive admission test and can tolerate unrelated errors in a failing fixture. A checker that returns the union of all expected codes could satisfy those four negative assertions. This is a test-strength limitation, not evidence that R1 currently behaves that way.

R2 should retain R1's four targeted negatives, add the ten cases reproduced here, and add positive controls for honest PARTIAL practice, QUESTION without P1, valid independently saved evidence, legitimate explicitly assisted observations, figure-free items, and genuinely reviewed/pinned key evidence. Assert the intended gate and reason, unaffected gates, and successful controls. Test missing/false values, duplicate IDs, hash mismatch, changed reviewer/authority status, same-total changed score vectors, and source-shape differences. Use the actual WPE field layout in synthetic fixtures. Do not put real examination passages or learner observations into distributable tests.

Every machine run must state its mode, input hashes, checker/adapter versions, checks attempted, unsupported checks and statuses. An unchecked requirement is NOT_RUN/UNKNOWN/HOLD as appropriate; it is not VERIFIED because no error was emitted. Zero exit may mean only that a specified integrity profile passed. It never signs academic semantics, official authenticity, independent review or learner mastery.

## M101, J2 and MAIN as a staged regression

Freeze the exact M101 source record and keep its AIEEE label, publisher provenance, absent official-key custody and figure-free layout honest. Independently classify and score that source. If QRT supports a direct JUSTIFY-D3 relationship, record the evidence; if not, retain a bridge. Either outcome is informative and must not be forced to satisfy a target cell.

Separately bind J2 and the parent MAIN. The latter's cut-spring requirement needs its own length-to-stiffness authority and complete different-example teacher preparation, in addition to the held-condition comparison. The locally available canonical WPE bytes do exist at the original path and match SHA-256 `84fe88387e33a03bf87bf1f537bae8c447f5b86f0d77a854c899ad70f12d8258`; their status is CANDIDATE. Byte availability is resolved here; approved spring-warrant qualification is a different, still-open question. R1's missing bundle/dependency evidence must not be misreported as global absence of the library.

Only the binder/compiler review can determine whether the completed teaching sufficiently prepares a fresh MAIN proof, whether the example is genuinely fresh, whether hints/figures/navigation disclose protected work, and whether all original content survived. D4.7 follows the concept note's own independently scored qualification. None of this switches this chat away from its paused D3.1 assignment or authorizes a production repair.

## Changes and present custody

Section 14 of the concept note was corrected in place, as requested: D3.7 then D4.7 is the active order; D3.5/D4.5 is historical/deferred evidence. A byte-for-byte pre-edit copy is stored here as `concept-note-before.md`. The replacement affected one exact paragraph.

Original skills under `chatgpt/output/skills`, original QRT records, Blueprint, WPE adapter, canonical library and received Downloads ZIP were not changed. The candidate `skills/` directory currently contains copied baselines, not a completed hardened skill release. Candidate validator authoring was deferred when the Owner asked for this deeper review. The new work consists of the note correction, intake/source receipts, isolated R1 reproduction, additional probes and this implementation specification. No installation or release took place.

**Recommended disposition:** adopt R1's responsibility model and priority order; correct its test-count claim and M101 task mapping; require source-aware adapters, verified dependencies and truthful observations before treating the next candidate as a gate. Continue with a small P0 candidate in copies, then the compact semantic handoff. Keep full Core1A/Core1B equivalence in the binder and keep academic/Owner acceptance distinct.

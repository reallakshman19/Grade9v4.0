# Smart Labelling → QRT hardening: R2 candidate

30 October 2026. **Implementation: candidate prepared and author-tested. Qualification: PARTIAL; independent review and academic acceptance remain open.**

This continues the existing R1 hardening proposal. It adds no Smart Labelling stage, installs no skill, changes no shared Blueprint, and does not resume D3.1 finalisation. The Owner authorized this chat as scoped Coder after the proposed single-agent 60-minute/60-call routine. The session returns to Oracle (standalone) after candidate delivery.

## What changed

Both candidate skills now use retained v1 overlays plus a versioned evidence sidecar. Their entrypoints retain the original record/content checks and require the new contract for qualification. Explicit `--legacy-only` remains available for migration and reports that qualification was not run. The legacy digest's meaning is unchanged.

The changes follow the agreed sequence:

| Layer | Implemented behavior | Qualification still required |
| --- | --- | --- |
| Source adapters and integrity | Exact byte hashes; separate question/answer payloads; actual figure-reference/assets binding; fixed adapters for ExamSIDE, WPE anchors, explicit-key JSON and saved text; per-item adapter selection; duplicate/coverage/dependency checks | Actual official-paper/key identity and any unsupported source extraction |
| Truthful attempts | Compare original reasoning, answer, confidence and exposure; exact task/version/stage; unique first successful save; explicit event order; UNKNOWN preserved; derived interpretation separately reviewed and bound to the resolved answer | Authentic historical capture and actual learner interpretation |
| Compact SL2 → QRT handoff | Typed intellectual requirement; operation-appropriate structure; competing interpretations; factor-by-factor prior comparison; separate first-scoring artifact and independent QRT receipt; one primary source coverage home | Actual decisive move, independently assessed demand and adjudicated source relationship |
| Construction binder | Source/task/family identities kept distinct; non-exam teacher task; current Blueprint/adapter and qualified-warrant pins; actual teaching/reconstruction spans; two-way role correspondence; independent B1–B7 receipt | Real teaching sufficiency, fresh reconstruction, protected work and substantive B1–B7 judgment |
| Downstream gates | Separate integrity, answer, practice, official paper/key, observation, QRT, canonical, construction and release gates; fresh dependency checking and blocking of stale promotions | Actual runtime/browser preservation and save tests, learner/Owner acceptance and release authority |

Each folder vendors the same helpers and both preserved legacy checker dependencies, so the two skills can run independently. The regression suite checks that those shared bytes match. The only in-memory legacy-rule extension is truthful UNKNOWN help exposure; the original legacy files are not edited. `prepare_contract.py` writes a new unreviewed snapshot and leaves semantic/review/binder fields open. It cannot silently create official custody, save history or academic approval.

SL2's seed remains a statement of the required thinking. Full lessons, qualified Physics and the complete Bridge Witness stay downstream. A source APPLY question may be a JUSTIFY prerequisite bridge without gaining JUSTIFY exam coverage. Direct exam evidence needs matching reviewed source operation/demand and separate paper/key custody.

M101 remains the AIEEE 2012 source question. The cut-spring MAIN is a separately authored bound task. The checker rejects reuse of the source examination ID as either that authored learner task or its non-exam teacher task. Matching a reusable family never establishes full task equivalence.

## Verification

**90/90 synthetic behavioral regressions passed**, including all four original deterministic false-pass categories, the ten additional R1 escape categories, typed-semantic/review/dependency attacks and positive controls. Assertions check the intended gate and reason, successful controls and unaffected gates. A test that accepts generic reasoning without semantic adjudication is treated as a semantic limitation, not a fifth proven false classification.

Positive controls include QUESTION mode without P1, explicit partial-practice policy, honest UNKNOWN exposure, explicitly assisted work, valid saved independent observations, figure-free questions, reviewed answer extraction, separate reviewed paper/key custody, cross-operation prerequisite bridges, and a fully synthetic reviewed binder/runtime contract. Synthetic approval receipts never constitute real review.

Both candidate SKILL files passed the skill-creator format validator. All candidate Python scripts compiled. The helper/CLI hashes, adapter IDs, exact input hashes, attempted checks, per-record gates and unsupported capabilities appear in execution reports.

The first test attempt could not write to Windows' sandbox Temp directory. Test data was moved under `tests/.runs` in the candidate workspace, with no recursive cleanup or original-file changes. One later launch exhausted local memory before a new result was written; the direct rerun completed. Its results caught and resolved an obscured JSON-pointer diagnostic and an unsynchronized helper copy. The final passing run is in [R2_REGRESSION_RESULTS.json](R2_REGRESSION_RESULTS.json), with the full log in [R2_TEST_LOG.txt](R2_TEST_LOG.txt).

## Trial against actual Owner-local data

The mixed-source trial reads the original four SL1/SL2 records without changing them. M84/N11 use `examside-json/v1`; AN5/AN1 use `anchors-json/v1`. Preparation resolves all four without adapter errors. Both legacy checkers return zero, while the strict contract holds actual unresolved dependencies:

| Record | New binding result | Interpretation |
| --- | --- | --- |
| M84 | Question integrity passes; answer extraction is unresolved | Publisher explanation exists, but no explicit source key or reviewed extraction is bound |
| N11 | Figure custody blocks integrity | Source figure references have no bound saved assets in this new contract |
| AN5 | Question integrity passes; source answer A has no copied SL1 key | An unfilled answer binding, not a finding that A is incorrect |
| AN1 | Question integrity passes; raw source answer `D (B and E only)` differs from copied `D` | A reviewed option/answer normalization is needed; the mismatch is not proof of a wrong answer or a historical key change |

No QRT adjudication, Physics qualification or learner result was manufactured to make this trial green. M101's source shape was separately read and pinned, with operation/demand explicitly NOT_ADJUDICATED and official key NOT_VERIFIED. See [R2_WPE_READONLY_TRIAL.json](R2_WPE_READONLY_TRIAL.json). Owner-local trial sidecars and full reports are in `working/`; they are deliberately excluded from the portable candidate ZIP.

## Preservation and custody

All seven original skill files still match the original source receipt. The corrected concept note, three Blueprint files, WPE adapter, canonical library and received R1 ZIP also match their recorded hashes: **14/14 comparisons** in [R2_PRESERVATION_REPORT.json](R2_PRESERVATION_REPORT.json). Source/label/library/vocabulary inputs additionally matched before and after the real-data trial.

The original concept note's §14 correction remains intact. No further original project document was edited. Original teaching, assessment, overlays and source files were preserved. D3.1 builds/repairs, browser execution, installation, remote writes and release were not performed.

I authored the candidate implementation, its probes and these tests and had prior exposure to R1 and the WPE context. These are author-side checks. There was no separate reviewer or subagent in this single-agent routine.

## How the next consumer uses it

Start with either candidate [SL1](../skills/smart-labelling-1/SKILL.md) or [SL2](../skills/smart-labelling-2/SKILL.md). The linked [contract reference](../skills/smart-labelling-1/references/hardening-contract.md) gives commands, shapes and exact gate meanings. Tests use Python's standard library:

```powershell
python -B -X utf8 tests/test_hardening.py
```

The next consumer is a **distinct independent reviewer**, assessing the exact candidate manifest/ZIP, actual source adapter behavior, negative/positive controls and whether the instructions support the intended QRT workflow. The supplied fixture factory contains only synthetic examples and no real trusted registry. For real promotion, the Owner must supply or recognize the actual reviewer registry and independently known hash pin; computing a hash of this candidate's synthetic registry cannot establish trust.

Actual answer extraction/normalization, official custody, independent operation/demand review, canonical warrant qualification, actual teaching/reconstruction and browser/learner acceptance remain separately open. Missing optional P1 does not block QUESTION mode or learning. No passing deterministic gate authenticates documents, certifies intellectual meaning or grants installation/release permission.

The current status/authority record is [R2_AUTHORITY_AND_PROGRESS.json](R2_AUTHORITY_AND_PROGRESS.json). The earlier R1 review and its deferred-implementation status are retained as historical evidence; this R2 delivery supersedes that implementation status only.

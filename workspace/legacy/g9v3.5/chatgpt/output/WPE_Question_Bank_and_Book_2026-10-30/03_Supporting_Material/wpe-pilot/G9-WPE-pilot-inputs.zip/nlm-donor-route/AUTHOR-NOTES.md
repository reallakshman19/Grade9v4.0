# AUTHOR-NOTES — NLM Core1A → Core1B, Grade9v3.5 / WBS 2.3

**Status:** `DRAFT_OWNER_VALIDATION` · **Author:** ChatGPT content author · **Date:** 2026-10-23 · **Output:** `nlm-core1ab.v1.json` (10 complete authored Core1A/Core1B pairs; 14 shared concept records). **Not** a compiled app, independently reviewed physics certification, QRT learner evaluation, PYQ set, or Owner acceptance.

## Input access and authority

Read the complete `CHATGPT-CONTENT-BRIEF.txt` first from `Handoffs/g9v35/G9-NLM-content-pack.zip`, then opened each of its **six** additional input files: `WBS-AND-TOP10.md`, `TILE-BLUEPRINT.v1.json`, `NLM-ADAPTER.v1.json`, `NLM-TOP10.v1.json`, `SOURCE-EXCERPTS.v1.json`, and `INPUTS.manifest.json`. All seven ZIP members were accessible. This author **did not** open the original full reference blueprints, original SVG figures, mechanics-question-bank full JSON, master-suite HTML, or library files listed in the manifest: the supplied source excerpt explicitly omits those larger components. The manifest's hashes are provenance, **not evidence of independent comparison**.

The user explicitly provided the Owner-stand-in **AGREED** order; it supersedes stale `PROPOSED_OWNER_AGREEMENT_PENDING` labels inside `NLM-TOP10.v1.json`. P1 remains done; no P2, seven-question diagnostic, mandatory generic re-check, all-topic expansion, code/commit, or independent review was performed.

## Reuse, adaptation and new authorship

- **Reused** current conceptual meanings, role and difficulty definitions from the supplied source excerpts and NLM adapter; aligned to the included canonical microtopic IDs where available. Reused the reference QRT family IDs solely as provenance and instructional focus, not as validated examination history.
- **Adapted/corrected** friction feasibility and force ownership, fixed-rope length coupling, frame conditions, normal force in an elevator, mass independence, signed impulses and internal-force pair cancellation. The six input artifacts govern tile mapping and nested JSON field shapes.
- **New**: all ten worked-anchor scenarios, all ten protected Core1B constructions (with full answers/rubrics), discriminating probes, actionable repairs and boundaries; 14 shared conceptual records, new constraints/impulse/conservation concepts where the current canonical mapping is absent, exact authored stage descriptions and sign/arrow labels, and the explicit difficulty assessments. Every Core1B test scenario is distinct from the Core1A solved anchor.
- Reused shared physics **by `concept_refs`**, not ten divergent claims of Newton's laws. In every tile, the Core1A and Core1B ID arrays match. Each concept has a teaching construction step and a Core1B reconstruct question; extra questions revisit dependencies when useful.

## Targeted primary-textbook sections

The following **OpenStax University Physics Volume 1** sections were consulted to strengthen specific HARD/MEDIUM transitions. They support textbook principles; task details and any movable-pulley extension are **authored**, not asserted to appear in those sections verbatim.

| Section | Specific support used |
|---|---|
| [§5.7 Drawing Free-Body Diagrams](https://openstax.org/books/university-physics-volume-1/pages/5-7-drawing-free-body-diagrams) | Only owned external forces on each body; force inventory before signed Newton-II equations; connected-body diagrams. |
| [§6.2 Friction](https://openstax.org/books/university-physics-volume-1/pages/6-2-friction) | Friction opposes relative motion/tendency and supports conditional static-versus-kinetic modelling. |
| [§9.2 Impulse and Collisions](https://openstax.org/books/university-physics-volume-1/pages/9-2-impulse-and-collisions) | Signed momentum change, impulse accumulation and **interval-average**, not peak, force. |
| [§9.3 Conservation of Linear Momentum](https://openstax.org/books/university-physics-volume-1/pages/9-3-conservation-of-linear-momentum) | Two-body action/reaction and the *system* external-force requirement. |
| [§6.3 Centripetal Force — noninertial-observer discussion](https://openstax.org/books/university-physics-volume-1/pages/6-3-centripetal-force) | Distinction between a real contact force and an inertial-frame-dependent apparent force; the **translating** frame equations in this pack are explicit authored coordinate derivations. |

## Ten-row completeness and QRT fit

`Core1A` = conventions + bridge + constructed justified steps + worked anchor + wrong-path repair + answered exit. `Core1B` = pre-answer prediction/attempt + full rubric and worked answer + purpose-built reconstruction questions + diagnosis/action repair + answered boundary test. All ten have stage-specific source-bound representations. Scores use the **current** five components each in 0–2; no conversion from the reference's distinct 1–5 average.

| Rank | Cell | Shared concepts | A steps | B reconstruction asks | B attempt / closure | Author score | Band status |
|---:|---|---:|---:|---:|---|---:|---|
| 1 | MODEL-D3 | 4 | 5 | 4 | Complete — choose static/kinetic and taut constraint | 7/10 | SUPPORTED (author rubric) |
| 2 | REPRESENT-D3 | 4 | 4 | 4 | Complete — body-specific FBD/third-law translation | 7/10 | SUPPORTED (author rubric) |
| 3 | APPLY-D3 | 3 | 4 | 4 | Complete — supplied impulse rule over signed intervals | 7/10 | SUPPORTED (author rubric) |
| 4 | SYNTHESIZE-D3 | 5 | 5 | 5 | Complete — invent coupling bridge, solve tension | 7/10 | SUPPORTED (author rubric) |
| 5 | MODEL-D4 | 5 | 5 | 5 | Complete — frame, wall contact, friction, reversal | 9/10 | **UNCERTAIN** (non-author review not done) |
| 6 | SYNTHESIZE-D4 | 6 | 6 | 6 | Complete — angled upper vs lower pull thresholds | 9/10 | **UNCERTAIN** (non-author review not done) |
| 7 | REPRESENT-D4 | 4 | 4 | 5 | Complete — signed three-strand rope routing | 9/10 | **UNCERTAIN** (non-author review not done) |
| 8 | JUSTIFY-D3 | 3 | 4 | 4 | Complete — qualified incline mass-independence proof | 7/10 | SUPPORTED (author rubric) |
| 9 | EXPLAIN-D3 | 4 | 4 | 4 | Complete — contact cause across elevator states | 7/10 | SUPPORTED (author rubric) |
| 10 | JUSTIFY-D4 | 5 | 5 | 6 | Complete — 3-cart cancellation, subset, interval countercase | 9/10 | **UNCERTAIN** (non-author review not done) |

**Actual authored-content omissions:** none of the ten required Core1A/Core1B pairs. All 28 cells are **not** authored: only the agreed ten are available; the other 18 remain planned/unavailable, including the four explicitly deferred high-band cells. There is no claim of all-green acceptance, integrated display behavior, independent checking or learner mastery.

## Source corrections and live physics qualifications

1. `PHYS-NLM-017` has a mismatch between stacked horizontal block stem and incline/tension factor prose; the authored FBD uses the horizontal body/contact geometry and omits wrong-setting factor claims.
2. `PHYS-NLM-018` has conflicting ratio wording. The authored two-moving-support-segment model counts signed length contributions directly, e.g. **−2z+x=constant** when z is load UP and x is free end RIGHT, so a_x=2a_z; on reversing free-end axis s=−x, a_s=−2a_z. The packet omits the original SVG, so equivalence to its layout is **not** asserted.
3. `NLM-08/RECON-04` includes an acceleration-weighted “virtual work” expression that is not a general principle. **Not reused.** For accelerating load, 2T−mg=ma_load; T=mg/2 only for zero vertical acceleration.
4. `PHYS-NLM-009` labels an unequal-speed rebound “elastic” and treats average as potentially peak force. New tasks do not assert elastic conservation; they use signed Δp and distinguish average force over the named interval from an undetermined peak.
5. The supplied `PHYS-NLM-005` entry contains unrelated impulse text in part of its derivation. New apparent-weight teaching was independently reconstructed from a package-only FBD; it does not inherit that mismatched ladder.
6. Static friction always tested as **needed ≤ capacity**; slipping uses μ_k only where given. A positive normal, an active taut/no-slip constraint and consistent signed axes are not implicit. Net zero **interval** impulse only means equality of endpoint momentum, not continuous conservation. No reference certificate or year is adopted as a verified PYQ.

## Self-checks actually performed

JSON parsed and serialized; the source pack order and all ten tile IDs checked against the agreed list; all `concept_refs`, source references, construction IDs, repair links, scene/stage links and B pre-attempt `GIVENS` links checked; ten pairs each have a complete attempt closure. Specifically checked that **no Core1A teaching step refers to a Core1B challenge ANSWER scene**. The authored JSON includes both answer and givens specifications; **the eventual builder must enforce the disclosure contract**—that UI behavior was not executed or tested here.

Recomputed representative numerical/sign/limit checks independently in local Python:

- MODEL-D3: static 15≤20 N versus 30>20 N; dynamic `a=20/7 m/s²`, `T=150/7 N`.
- REPRESENT-D3: `a=9/5=1.8 m/s²`, interface friction `5.4 N` vs static limit `8 N`; normal from floor `50 N`. Core1A exit F=18 N is **exactly** the permissible threshold, not a failing case.
- APPLY-D3: signed momentum chain `−1 → +1 → −0.2 → +0.8 kg·m/s`, missing `F_III=+10 N`, full-run `F_avg=+1.8 N`.
- SYNTHESIZE-D3: net driving `(20−6)=14 N`, combined `5 kg`, `a=2.8 m/s²`, `T=14.4 N`; independently checked against both bodies.
- MODEL-D4: vertical wall `N=36,48 N` for A=18,24; friction capacities `18<20` and `24≥20 N`; left acceleration gives negative tentative normal, hence loss of rear-wall contact.
- SYNTHESIZE-D4: angled top `f_required=12F/25`, `N=20−3F/5`, threshold `F=100/9 N`; candidate F=10 feasible and F=12 infeasible; horizontal lower-pull max `20 N`. Candidate F=12 acceleration is not represented as actual post-slip acceleration.
- REPRESENT-D4: `−2Δz+Δx=0`; upward load acceleration `1 m/s²` gives `T=44 N` at `m=8 kg`; left `Δx=−0.30 m` gives load down `0.15 m`.
- JUSTIFY-D3: smooth slope `a=6 m/s²`, same `t=2 s`; adding identical upslope `2 N` gives `a=4,5.5 m/s²` for 1/4 kg.
- EXPLAIN-D3: normal `40,10,0,65 N` for stated 5 kg elevator acceleration episodes; floor accelerating down `12 m/s²` cannot impose a negative compression normal.
- JUSTIFY-D4: total signed momentum `P_ABC: −1 → +3 → −1 kg·m/s`; `AB` external impulses `+3` and `−8 N·s`; member impulses sum to same totals.

These checks establish local arithmetic and link consistency, **not** line-by-line independent scientific review or code compilation.

## Outstanding / next-owner awareness

- Four D4 band-fit claims remain **UNCERTAIN** because the 0–10 scores are author assessments, not independent calibration. The packet recommended a bounded non-author content spot-check particularly for MODEL-D4, SYNTHESIZE-D4 and REPRESENT-D4 (and any other flagged discrepancy); **not performed** here.
- Original omitted SVG art and the full reference corpus were **not read**; no geometric equivalence to those original figures is claimed. The authored diagram descriptions define their own complete layouts and directions. An illustrator or local renderer should use **these specifications**, not invent physics or rely on omitted assets.
- Display order, math rendering, touch targets, SVG labels, help/exposure tracking and the 28-cell navigation map are instructions for the local builder; **not compiled, launched or Chrome-tested** in this authoring response. The Owner's eventual B2 validation remains separate.
- No other physics discrepancy is presently identified in the authored calculations; this is **author self-check only**, not a guarantee that none exists.

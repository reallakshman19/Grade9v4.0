# Owner-launch brief — WBS 2.4, compile NLM Core1A/1B tiles

Aim: one Grade 10 learner uses clear, guided material to understand why NLM works, break concepts into parts and apply them towards JEE Main. Exam year deferred. This is the NLM proof before other topics.
Modules: prototype-first; shared six-Core semantics; supplied tile blueprint and NLM adapter.
User can: open one NLM learning page, select a priority QRT tile, read its full Core1A explanation, then reconstruct the same idea in Core1B.
Authority: Owner launches the local builder. Oracle has not launched you. This supersedes the P2 amendment; do not build another diagnostic or repair P2. Preserve P1 and P2 artifacts.

## Inputs and scope

- Source repo: C:/CodeC/Grade9v3.5, current grounded main 7052691eb97351d1b7e8f22200f733adafb0f13c. Confirm the actual implementation base/custody with the Owner; do not reset a worktree or overwrite another writer.
- Oracle packet: oracle-handoffs/G9O5-5/{WBS-AND-TOP10.md,TILE-BLUEPRINT.v1.json,NLM-ADAPTER.v1.json,NLM-TOP10.v1.json}. Use the Owner-agreed list, not an assumption of approval from the draft files.
- Actual authored input: nlm-core1ab.v1.json and AUTHOR-NOTES.md returned by ChatGPT for WBS 2.3. These do not exist merely because this brief names them. Do not fill their absence with generated placeholder teaching. Layout scaffolding can proceed, but a ten-unit content result requires that actual input.
- Presentation reference: golden/Reference/physics-olympiad-grade9-master-suite.html, 17,075,720 bytes when inspected. Reference only; may reuse its relevant visual/navigation ideas or assets with provenance. Do not copy the entire 200-question suite into the new product or reproduce its certification claims.
- Academic contracts: Shared/roles/README.md, CORE1A.md, CORE1B.md; Physics/adapter/CoreContracts.json and DemandReview.json; current Shared/vocabularies. Read Shared/library/compile_inputs.py for established preservation/projection patterns. That compiler accepts canonical library packages; the new content pack is not automatically such a package. Use a small local presentation/projection adapter if needed. Do not redesign the Shared compiler/schema or claim an unsupported format is already compatible.
- Reference directory and its JSONs remain untracked, unchanged and uncommitted unless the Owner explicitly says otherwise. Do not stage unrelated changes or private material. New handoff files are design inputs, not an authorization to commit everything under oracle-handoffs.

Timebox: four builder hours after actual content input. First hour: render one complete real unit end-to-end from the supplied pack, then apply the same structure to the other nine in the same build. This internal implementation order is not another Owner prototype/review loop. If the full compile cannot fit, report the actual limitation; do not quietly omit units or call empty tiles complete.

## One page, modelled on the useful master-suite structure

Deliver a local folder such as standalone/study/nlm-core1ab/ with an offline index.html, deterministic compile command, local assets as needed, one Chrome launcher and a short README. A self-contained final HTML is welcome if straightforward; do not add a server/account/backend merely for this page.

Top navigation: NLM title, a clear path to Core1A and Core1B, demand/band filters, text search and a compact idea atlas/prerequisite map. Show all 28 QRT cells: ten content-complete paired tiles are available; the other 18 are visibly planned, without fake content or disabled links that pretend to open a lesson. Priority is an authoring order, not a lock on learner navigation. Preserve the agreed rank as an optional ordering.

Each available tile opens its own meaningful learning material. Core1A's completed construction and reasoning are visible; do not gate declarative teaching behind a question. Explain conventions, inference, linked diagram, full conceptual example, wrong path/repair and exit closure. Core1B then presents prediction/attempt before reconstruction, diagnosis, repair and boundary closure. Each prompt's answer/rubric stays accessible by deliberate reveal; a learner may say cannot_yet. Do not force a text-length gate, an extra fresh test, a quiz pass or completion of P1 before reading.

Keep Core1B solution equations, model answers and revealing visual stages out of the initial rendered/accessibility surface. Avoid leakage via SVG title/desc, alt text, captions, answer-specific menus or default expanded details. An explicit 'show reconstruction/answer' request may reveal help and should not require invented filler. No automatic semantic grading or mastery claim. Core1A may have taught the method; the Core1B work still needs to elicit the declared inference, not simply repeat an exposed answer.

Diagrams are functional: correct bodies/receivers, arrow directions and signs; labels correspond to the equations. Use authored scene specifications and stage descriptions. Reuse existing valid SVG/scene assets where appropriate, stripping solved stages and their accessible descriptions from the pre-attempt projection. Ask the content author/Owner about a physics gap; do not silently invent academic truth to make a component render.

Compile TeX to readable math using available local tooling; bundle any needed assets so the result works offline. Resolve reference paths to local packet inputs, not stale TEST/physics-research paths. Readable phone/laptop layout, diagram text at least 14 px and comfortable touch targets (reference uses 48 px). No unexplained engineering IDs, compiler metadata or review gates in the learner's reading path. Put source mapping, uncertainties and author notes in an Owner/source view.

Minimum continuity: preserve current tile/Core and any Core1B attempts, edits and reveal/help state locally; provide a local save/load file if needed to avoid losing written work across sessions. No learner profile/score/adaptive ladder required. Keep attempted, revealed and completed distinct; no telemetry service. Reference-only and authored provenance remain visible in the Owner view, and an authored problem must not acquire a fictitious JEE year/number.

## Bounded verification and return

One compile-time check covers: exactly the agreed ten unique tiles with both Cores and matching concept IDs; 28 cells with honest availability; prompt closure; resolvable links/scene IDs; valid rendered math; and no missing input silently converted to content. Add a small focused check only where disclosure/state behavior needs it. Reuse existing checks/helpers when useful, not a new broad test project. No P1/P2 test or screenshot loop is a prerequisite here.

OTM opens the final compiled page once in real Chrome to confirm it works. Owner then validates the actual page against the reference's readability/navigation and the aim. No mandatory PR, screenshot exchange or repeated review cadence. Owner validation is B2; do not assert it yourself.

A single independent content spot-check before the kid is still planned for MODEL-D4, SYNTHESIZE-D4 and REPRESENT-D4 plus unresolved physics/tag discrepancies, because errors in frame/contact/constraint reasoning can teach the wrong model and the reference contains contradictions. This is separate from the Owner DRAFT validation, not another prototype. No reviewer is launched by this brief.

Return: actual launcher/path and compile command; base and exact candidate head if a commit is separately authorized; files changed; ten-row coverage and known gaps; checks actually run and failures; content/reference hashes; local save/reopen behavior. Clearly distinguish your own testing, OTM's browser run, Owner validation and the non-author content spot-check. No merge, deployment, publication, acceptance or other-topic work is granted.

# Detailed Reference: The 7 Critical Anti-Patterns & Code Fixes

This document details the exact code patterns, regression risks, and drop-in fixes for the 7 anti-patterns in Core 2 engineering.

---

### 1. Lexical Ghost Text ("2. Connection:")

* **The Defect:**
  Legacy generators output:
  ```json
  "reasoning": [
    "1. System Representation & Setup: ...",
    "2. Connection: By applying Work-Energy Theorem ...",
    "3. Execution & Resolution: ..."
  ]
  ```
* **The Fix:**
  Replace with the canonical scientific modeling header:
  ```json
  "reasoning": [
    "1. System Representation & Setup: Declare system boundary [block + incline + Earth] and datum U = 0.",
    "2. Physical Model & Formulation: Formulate Work-Energy balance W_g + W_f = Delta K.",
    "3. Execution & Resolution: Solve algebraically for mu = 3*tan(theta)."
  ]
  ```

---

### 2. Static Crux Move Hardcoding

* **The Defect:**
  Statically writing `"crux_move_ref": "WPE-B5-QXX-M2"` for every item.
* **The Fix:**
  Dynamically bind the crux reference and the protected scaffold:
  ```python
  if op in ("RETRIEVE", "REPRESENT"):
      crux_ref = f"WPE-BX-Q{seq:02d}-M1"
      scaf_crux_tier = 1
  elif op == "JUSTIFY":
      crux_ref = f"WPE-BX-Q{seq:02d}-M3"
      scaf_crux_tier = 3
  else: # MODEL, SYNTHESIZE, APPLY
      crux_ref = f"WPE-BX-Q{seq:02d}-M2"
      scaf_crux_tier = 2
  ```

---

### 3. Complexity Rubric Sum Drift

* **The Defect:**
  Setting `score: 7` while components sum to `5`, or scoring an individual component $> 2$.
* **The Fix:**
  Strictly score all 5 dimensions in $\{0, 1, 2\}$ and compute total score as the sum:
  ```python
  comp_scores = {
      "concept_model_selection": 1,
      "representation_translation": 2,
      "reasoning_chain_length": 2,
      "algebra_computational_load": 1,
      "trap_exception_sensitivity": 1
  }
  total_score = sum(comp_scores.values()) # Exactly 7 -> Band D3
  assert all(0 <= v <= 2 for v in comp_scores.values())
  assert sum(comp_scores.values()) == total_score
  ```

---

### 4. Non-Canonical Verbs

* **The Defect:**
  Using `"kind": "CALCULATE"`, `"kind": "SOLVE"`, `"kind": "IDENTIFY"`, or `"kind": "CONNECT"`.
* **The Fix:**
  Filter against canonical 7 verbs only:
  ```python
  CANONICAL_OPERATIONS = {
      "RETRIEVE", "EXPLAIN", "APPLY", "MODEL", "REPRESENT", "SYNTHESIZE", "JUSTIFY"
  }
  assert move_kind in CANONICAL_OPERATIONS
  assert primary_op in CANONICAL_OPERATIONS
  ```

---

### 5. Invalid SVG Root Dimensions

* **The Defect:**
  `<svg viewBox="0 0 540 280" width="100%" height="auto">`
  Chromium throws: `Invalid attribute value: height="auto"`.
* **The Fix:**
  ```xml
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 280" width="100%" height="100%">
  ```
  And in CSS:
  ```css
  .q-fig-box img, .q-fig-box svg {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 0 auto;
  }
  ```

---

### 6. Mobile Viewport CSS Cascade Order

* **The Defect:**
  Declaring `.drawer-card { position: sticky; }` *after* the `@media (max-width: 900px)` block.
* **The Fix:**
  Place desktop styles first, followed by mobile media queries:
  ```css
  /* Desktop styles */
  .drawer-nav { position: sticky; top: 80px; }
  .num-input { max-width: 220px; }

  /* Mobile overrides */
  @media (max-width: 600px) {
    .drawer-nav { position: static; }
    .num-input { max-width: 100%; }
    .commit-btn { width: 100%; }
  }
  ```

---

### 7. Formative Derivation Leaks

* **The Defect:**
  Derivation sections visible before learner attempt.
* **The Fix:**
  Hardcode `display: none;` on `.derivation-section` and require an event to commit:
  ```css
  .derivation-section { display: none; }
  .derivation-section.revealed { display: block; animation: fadeIn 0.3s ease; }
  ```
  ```javascript
  function commitAnswer(seq) {
    state.committed[seq] = true;
    document.getElementById('commit-btn-q' + seqStr).disabled = true;
    const deriv = document.getElementById('derivation-q' + seqStr);
    if (deriv) {
      deriv.classList.add('revealed');
      deriv.style.display = 'block';
    }
  }
  ```

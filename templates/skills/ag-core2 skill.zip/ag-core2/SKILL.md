---
name: ag-core2
description: >-
  Standard operating procedure, architectural standard, and automated runbook for
  authoring, auditing, remediating, and packaging Grade9 Core 2 Source Question Learning Modules:
  Bounded Transfer Protocols (Work Order -> Delivery -> Repair Return -> Evidence Receipt),
  4-Gate Zero-Escape Foolproof Checklist, QRT 7-Operation Cognitive Demand, 5-Factor Rubric Bounds [0..2],
  Dynamic Crux Binding, Commitment-First Inert Derivations, W3C SVG Typography (>=14px), and Dual-Engine
  Verification (Python Unit Tests + Headless Playwright Viewport Audits).
---

# AG_Core2: Grade9 Core 2 Source Question Engineering Runbook

## Overview & Purpose

The **`ag-core2`** skill defines the canonical lifecycle, schemas, validation gates, and compilation procedures for transforming raw competitive exam items (e.g. JEE Main, NSEP, IPhO, Foundation) into interactive, tablet-ready **Core 2 Source Question Learning Modules**.

This skill operationalizes the **Physics QRT Blueprint (`PHYS-QRT-BLUEPRINT`)**, enforces the **Commitment-First Pedagogical Contract**, permanently prevents the **7 Critical Anti-Patterns**, and governs the **4 Bounded Transfer Protocols** between the Oracle, Builder, and Reviewer.

> [!IMPORTANT]
> **Universal Governance Invariant (Rule 13 in `AGENTS.md`)**:
> *"No academic approval inferred from software validation. Green CI means automatic tests passed; it never means student release is authorized."*
> All authored questions must default to `HOLD:ACADEMIC_ADMISSION` / `NOT_ADMITTED`. Software audits certify only syntactic, structural, and layout conformance.

---

## 1. The 7 Critical Anti-Patterns & Enforced Rules

Every Core 2 authoring and review session must strictly enforce compliance against these 7 failure modes (detailed in [`references/CRITICAL_ANTIPATTERNS.md`](references/CRITICAL_ANTIPATTERNS.md)):

| # | Anti-Pattern | Enforced Rule | Remediation Mechanism |
|---|---|---|---|
| **1** | **Lexical Ghost Text** (`"2. Connection:"`) | Section headers must strictly follow: `1. System Representation & Setup:`, `2. Physical Model & Formulation:`, `3. Execution & Resolution:`. | Zero tolerance for `"Connection"` in reasoning lists or DOM text. |
| **2** | **Static Crux Hardcoding** (`crux_move_ref = "M2"`) | Crux move must be **dynamically bound** based on primary cognitive demand. | `M1` for `RETRIEVE` / `REPRESENT`; `M2` for `MODEL` / `SYNTHESIZE` / `APPLY`; `M3` for `JUSTIFY`. Registered in `protected_move_refs`. |
| **3** | **Rubric Sum Drift** ($\sum c_i \neq \text{score}$) | Each of the 5 QRT complexity dimensions must be scored strictly in $\{0, 1, 2\}$, and their sum must exactly equal `difficulty.score`. | Strict unit test assertions: $c_i \in \{0, 1, 2\}$, $\sum c_i = \text{score}$, mapping to D1 (0–2), D2 (3–5), D3 (6–7), D4 (8–10). Never dilute to $\le 4$. |
| **4** | **Non-Canonical Verbs** (`CONNECT`, `CALCULATE`, `SOLVE`) | All primary operations, reasoning move kinds, and scaffold support types must belong strictly to the 7 canonical verbs. | $V_{\text{canonical}} = \{\text{RETRIEVE}, \text{EXPLAIN}, \text{APPLY}, \text{MODEL}, \text{REPRESENT}, \text{SYNTHESIZE}, \text{JUSTIFY}\}$. |
| **5** | **Invalid SVG Root Dimensions** (`height="auto"`) | Root `<svg>` tag must specify explicit length/percentages: `width="100%" height="100%"` with a responsive `viewBox`. Aspect ratio is managed via CSS. | Prevents Chromium SVG parser warnings in headless browser audits. Font sizes inside SVG must be $\ge 14\text{px}$. |
| **6** | **Mobile Viewport CSS Cascade Order** | Base desktop layout styles must precede `@media` queries; on mobile, sticky containers must reset to `position: static;`. | Guarantees 0px horizontal scroll overflow on 375px mobile viewports and prevents touch interception. |
| **7** | **Formative Derivation Leaks** | Derivations must remain strictly inert (`display: none;`) in the DOM until the learner commits an answer. | Dual event handlers unlock derivations only upon user commitment (MCQ selection or numerical input). |

---

## 2. Core 2 Blueprint Cognitive Slot Architecture ($X, Y, Z, W$)

Every question derivation is structured into 4 standardized cognitive slots:

1. **Slot $X$ (Given Constraints & System Boundary):**
   - Declared in **Move 1** (`REPRESENT` or `RETRIEVE`).
   - Must state the explicit physical system boundary (e.g. `[body + incline + Earth]`) and reference datum (e.g. $U_{\text{grav}} = 0$ at incline base).
2. **Slot $Y$ (Demonstrated Anchor / Law):**
   - The governing physical principle (e.g. Work-Energy Theorem, Newton's 2nd Law, Conservation of Mechanical Energy).
3. **Slot $Z$ (Dependent Route / Formulation):**
   - Declared in **Move 2** (`MODEL` or `SYNTHESIZE`).
   - Sets up the integral, dynamic balance, or multi-stage state transition.
4. **Slot $W$ (The Protected Crux Move):**
   - The decisive cognitive pivot (e.g. algebraic root extraction, completing the square, vector dot product, or warrant).
   - Must be listed in `extensions.grade9v3:core2_support_plan.protected_move_refs`.
   - **Pre-Attempt Scaffolds (H1–H3) must NEVER reveal $W$.**

---

## 3. The 3-Tier Progressive Hint Scaffold (H1, H2, H3)

Every Core 2 question must include exactly 3 progressive pre-attempt hint tiers:

- **Tier 1 — H1 (`CLARIFY` / `REPRESENTATION`):** Clarifies what the question turns on, coordinate axes, and declared datums.
- **Tier 2 — H2 (`CORRELATE` / `FORMULATION`):** Links the crux to a demonstrated law ($Y$) without performing the execution.
- **Tier 3 — H3 (`OPEN_THE_WAY` / `RESOLUTION`):** Opens the algebraic/conceptual route ($Z$) without executing the protected crux move ($W$).
- **The "Never" Invariant:** No hint may reveal the answer, state the final numerical value, or eliminate MCQ options.

---

## 4. UI / Tablet Blueprint Standards

1. **Commitment-First Interactive Controls:**
   - **MCQ Questions:** Radio buttons with WCAG 2.5.5 touch target height $\ge 44\text{px}$. Selecting an option enables the commit button.
   - **Numerical Questions:** Responsive `.num-input-group` with `flex-wrap: wrap;` and `box-sizing: border-box;` (max-width $220\text{px}$ on desktop, $100\%$ on mobile). Entering text enables the commit button.
   - Clicking **Commit** disables the inputs, freezes the choice, and animates `.derivation-section` to `display: block;`.
2. **MathML Math Formatting:**
   - Mathematical expressions, fractions ($\frac{A}{B}$), powers ($10^7, t^{3/2}$), units ($\text{m/s}^2$), and vector hats ($\hat{i}, \hat{j}, \hat{k}$) must render via semantic native `<math class="math-tex">` tags without external CDNs.
3. **Responsive Mobile Isolation:**
   - Container padding $\le 12\text{px}$ on mobile screens ($\le 600\text{px}$).
   - Zero horizontal scroll overflow across both Mobile (375x812) and Desktop (1365x900) viewports.
   - Instantaneous scroll navigation via `scrollIntoView({ behavior: 'auto' })` (never `'smooth'`).

---

## 5. The Four Bounded Transfer Protocols

Work between agents is governed by strict bounded transfer protocols (see [`references/TRANSFER_PROTOCOLS.md`](references/TRANSFER_PROTOCOLS.md)):

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           THE FOUR TRANSFER PROTOCOLS                                   │
├──────────┬─────────────────────────────┬────────────────────────────────┬───────────────┤
│ Protocol │ Channel & Direction         │ Primary Artifact / Schema      │ Gate Action   │
├──────────┼─────────────────────────────┼────────────────────────────────┼───────────────┤
│ **TP 1** │ Oracle → Builder            │ `WORK_ORDER.json`              │ Dispatch      │
│ **TP 2** │ Builder → Reviewer          │ `CODER_DELIVERY_TRANSACTION`   │ Handoff       │
│ **TP 3** │ Reviewer → Builder          │ `LOCAL_EXECUTION_RETURNED`     │ Repair Return │
│ **TP 4** │ Reviewer → Oracle / B2      │ `BATCH_ARCHIVE_RECEIPT.json`   │ Evidence Lock │
└──────────┴─────────────────────────────┴────────────────────────────────┴───────────────┘
```

1. **TP 1: Work Order Dispatch (Oracle $\to$ Builder):** Read-only bounded scope (`G9V4_LOCAL_AGENT_WORK_ORDER_SCHEMA_v0.1.json`). Halts on baseline drift.
2. **TP 2: Delivery Handoff (Builder $\to$ Reviewer):** Requires sealed candidate ZIP, `CODER_DELIVERY_TRANSACTION.json`, and the standard 6-line delivery report. Verified via `python scripts/verify_handoff_transaction.py`.
3. **TP 3: Repair Return (Reviewer $\to$ Builder):** Dispatched upon any audit failure via `LOCAL_EXECUTION_RETURNED.json` specifying exact error codes and bounded repair targets.
4. **TP 4: Escalation & Receipt (Reviewer $\to$ Oracle / B2):** Issues detached cryptographic receipt under `HOLD:ACADEMIC_ADMISSION` or `GAP_NOTE.json` if blueprint ambiguity is discovered.

---

## 6. The 4-Gate Zero-Escape Foolproof Checklist

Every delivery must pass through all 4 sequential gates without bypass:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                       THE 4-GATE ZERO-ESCAPE CHECKLIST                                  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 0: INTAKE & SOURCE CUSTODY                                                         │
│ [ ] Bit-for-bit stem SHA-256 match against source audit record (0-character drift).     │
│ [ ] Sequential ordering (1..N contiguous) without missing or duplicate IDs.             │
│ [ ] Explicit question type declared (MCQ with options >= 2, or Numerical with []).      │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 1: QRT BLUEPRINT & COGNITIVE DEMAND                                                │
│ [ ] Exactly 0 occurrences of ghost text ("Connection:").                                │
│ [ ] Strict canonical 7-verb membership (RETRIEVE, EXPLAIN, APPLY, MODEL, etc.).        │
│ [ ] 5-Factor complexity rubric: each c_i in {0, 1, 2} and sum(c_i) == difficulty.score.│
│ [ ] Dynamic crux move binding (M1: Repr/Retr, M2: Model/Synth/Apply, M3: Justify).      │
│ [ ] Move 1 explicitly declares system boundary [body + incline + Earth] & datum U = 0.  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 2: FRONTEND, TYPOGRAPHY & DOM STANDARDS                                            │
│ [ ] Pre-rendered static MathML typography (<math class="math-tex">); 0 external CDNs.   │
│ [ ] W3C compliant SVG root attributes (width="100%" height="100%"); never height="auto".│
│ [ ] SVG typography font-size >= 14px on all technical labels and dimensions.            │
│ [ ] CSS cascade order: Desktop styles declared BEFORE @media (max-width: 900px).        │
│ [ ] Instantaneous scroll navigation (behavior: 'auto'; never 'smooth').                 │
│ [ ] Touch target height >= 44px on all pills, option buttons, and accordion headers.    │
│ [ ] Derivations remain display: none until explicit commitment (MCQ click / Num input). │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 3: DUAL VERIFICATION, SEALING & DETACHED RECEIPT                                   │
│ [ ] Python unit suite (test_batchXX.py) passes with exit code 0; logs captured.         │
│ [ ] Playwright audit passes with 0 console errors, 0 network errors, and 0px overflow.  │
│ [ ] Sealed ZIP created with MANIFEST.json recording all payload SHA-256 hashes.         │
│ [ ] Detached receipt records archive SHA-256 and disposition HOLD:ACADEMIC_ADMISSION.   │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Dual Automated Verification Gate

Every batch or standalone compilation must pass two mandatory automated test suites:

### 1. Python Unit Test Suite (`test_batchXX.py`)
Must verify:
- `test_01`: Manifest integrity, batch ID, question counts, and `HOLD:ACADEMIC_ADMISSION`.
- `test_02`: Verbatim stem SHA-256 invariance (0-character drift against source audit records).
- `test_03`: Canonical 7-verb membership for all primary ops, moves, and scaffolds; 5-factor rubric bounds in $\{0, 1, 2\}$ with $\sum c_i = \text{score}$.
- `test_04`: Declared system boundaries and $U=0$ datums.
- `test_05`: 3 hint tiers and protected crux move registration.
- `test_06`: SVG asset existence and typography $\ge 14\text{px}$.
- `test_07`: Inert HTML template privacy (derivations hidden by default, zero external CDN links).
- `test_08`: Adversarial negative mutation tests (tampered stems, forbidden verbs, and fake approvals fail closed).

### 2. Headless Playwright Audit (`verify_batchXX_playwright.js`)
Must verify:
- Viewport width check: Mobile (375x812) and Desktop (1365x900) with exact **0px horizontal scroll overflow**.
- Touch target check: All interactive elements $\ge 44\text{px}$ height.
- MathML element count $> 0$.
- Interactive question switching, hint accordion toggling, and commitment-locked derivation exposure for both MCQ and Numerical items.
- Zero console errors and zero HTTP 4xx/5xx network errors.

---

## 8. Packaging & Cryptographic Sealing Procedure

Once tests pass, package the review artifacts using the standard sealing protocol:
1. Capture `BATCH_TEST.log` and `BATCH_PLAYWRIGHT_TEST.log`.
2. Compile `MANIFEST.json` containing individual payload file sizes and SHA-256 hashes.
3. Compress payload files into a sealed ZIP archive: `CORE2_BATCH_XX_PRIVATE_REVIEW.zip`.
4. Author a detached cryptographic receipt: `BATCH_XX_ARCHIVE_RECEIPT.json` capturing the archive byte size and SHA-256 digest.
5. Verify local mirror server returns HTTP 200 on all endpoints.

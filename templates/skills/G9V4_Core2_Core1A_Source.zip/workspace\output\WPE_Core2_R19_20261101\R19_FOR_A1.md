# R19 findings for A1 (process check copy)

No question text, options, stem numbers or keys are in this file. IDs, verdicts, reasons and gates only. Everything is HOLD; admissions remain zero. No academic approval is inferred from software validation.

Factor order: concept, representation, chain, algebra, trap. D3 = 6-7, D4 = 8-10.

| ID | Batch | Proposed | R19 cell | Physics vs stored key/explanation | Adapter fit | Gate |
|---|---|---|---|---|---|---|
| EX-M39 | 07 | SYNTHESIZE D3 | SYNTHESIZE D3 (6-7), MODEL competing | AGREE with third-party explanation; no key stored | PARTIAL (D3.6 family S1, no R3 subset owns it) | HOLD |
| EX-M44 | 07 | SYNTHESIZE D3 | SYNTHESIZE D3 on demand, MODEL competing | UNDETERMINED (explanation truncated, no key) | OUT_OF_SCOPE (collisions excluded) | HOLD |
| EX-M60 | 07 | SYNTHESIZE D3 | APPLY D2 (4-5) | AGREE with third-party explanation; no key stored | OUT_OF_SCOPE and below band | HOLD |
| EX-M101 | 08 | JUSTIFY D3 | APPLY D2 (4-5) | AGREE with third-party explanation; no key stored | PARTIAL/HOLD (D3.7.2 projection HOLD) | HOLD |
| WEP07-03 | 09 | JUSTIFY D4 | APPLY D2 (upper D2) | AGREE with official final key per R1 (my solve not key-blind) | No D4 slice exists | HOLD |

## Reasons, per ID

- **EX-M39.** Deciding move: an energy bridge links the two positions of the swing. Two-stage, one bridge, routine algebra: fits the D3.6 pattern. MODEL is a credible competitor and is not settled. Conflicts: score 6 (ledger, registry) vs 7 (coverage map); ledger names subtile D3.6.1 while the D3.6.1 projection binds a different family.
- **EX-M44.** Two stages under different laws joined by a shared speed: SYNTHESIZE on demand. But the WPE topic adapter declares collisions out of scope, and the D3.6 package quarantines the item. The registry still nominates it for slot SYNTHESIZE-3: cross-package conflict. Publisher explanation stops before the final value. Score 6 vs 7 across records.
- **EX-M60.** Routine conservation step then direct substitution: chain length 1, no hidden bridge. I disagree with SYNTHESIZE D3. The D3.6 ledger already scored it APPLY D2 (4). The V4 registry has it unassessed and not selected; I could not find the source of the SYNTHESIZE D3 proposal.
- **EX-M101.** Two familiar formulas with the controlled variable switched; the reversal is a real trap but the task does not require stating warrant, conditions and boundary (the D3.7 evidence criterion). Assertion-reason format alone does not make JUSTIFY primary. I agree with R1's independent APPLY D2, not JUSTIFY D3. It is a same-force/same-extension comparison, not the cut-spring MAIN.
- **WEP07-03.** NSEP, not JEE Main. One conserved-energy observation plus completing a square resolves every option; the item's supplied forms allow verification. No converse/boundary claim to refute, so the D4.7 pattern is absent. I agree with R1's APPLY D2, not JUSTIFY D4. The JUSTIFY D4 score in the D3.7 package belongs to an author-created refutation probe, not the original item. The withdrawn "source conflict" claim stays withdrawn; my reading of the crop agrees with R1. Classifications on file disagree four ways (SYNTHESIZE D4, JUSTIFY D4 probe, JUSTIFY D4 proposal, APPLY D2).

## Open holds named
- Official paper item and key binding: NOT_RUN for EX-M39, EX-M44, EX-M60, EX-M101.
- WEP07-03: registry record still lacks extracted text and still says official key not retained/bound; paper code 61 vs Set 611 not closed in any file read.
- Collision scope (EX-M44, EX-M60) needs an Owner decision and a source.
- Registry slots SYNTHESIZE-3 (EX-M44) and JUSTIFY-1 (EX-M101) are not updated to reflect the out-of-scope and lower-band findings. Flagged, not changed.

## Closest to admission (of 14)
**WEP07-03.** Only candidate with official paper, official final key and official worked solution on file, plus a sealed blind independent review agreeing. Missing: Owner decision to admit it as a labelled APPLY D2 question (it does not fill a D3/D4 slot); record-level binding of the official key evidence; code 61/611 closure; exact text extraction; native render with independent QA; Owner approval. If a D3/D4 slot is required for the first admission, the next best is EX-M39, which lacks its official paper item and key.

## Process notes for A1
- Solves were done before reading explanations/keys, except WEP07-03: the brief disclosed its official key before my solve.
- R18 summary was read from the public PR branch through a read-only GitHub API call, because the branch is not in the local repository.

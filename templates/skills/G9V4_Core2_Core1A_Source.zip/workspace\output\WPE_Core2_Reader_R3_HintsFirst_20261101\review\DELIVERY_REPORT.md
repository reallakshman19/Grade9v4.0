# Core2 reader R3: hints any time, full answer last

**Open:** [rendered/core2.html](../rendered/core2.html)
(`D:/CodeD/grade9v4/workspace/output/WPE_Core2_Reader_R3_HintsFirst_20261101/rendered/core2.html`)

## What changed on every card (after the Owner's "Allow before attempt")
- **Hints can be used before or after an attempt.** The panel "Need a hint? · one at a time" opens one rung per click (H0, then H1, and so on), as in R1 and R2.
- **One button opens the full answer.** "Show full answer and working" holds the key, the steps and the common wrong route. It sits below the hints, is locked until you have made an attempt, and opens only when you press it. It never opens by itself.
- **Answers stay editable.** You can change your ticks or typed answer after reading a hint, and the change is saved. A blank attempt is still refused.
- **Reload keeps your place.** It brings back the hints you opened (even before an attempt), your answer, and whether the full answer was open.
- **NSEP card:** after an attempt, the difficulty line now reads "Difficulty: APPLY D2 (5/10), decided by the Owner on 1 Nov 2026. One reviewer rated it MODEL D3 (7/10)." The decision is recorded in REVIEW_RECORDS.json and closes the difficulty dispute. Admission stays on HOLD.

## Proof
47/47 browser checks passed in headless Chromium, with no page errors. They were rerun after the rebuild for the Owner's difficulty decision. They cover the NSEP card and three textbook cards (Illustrations 3, 6 and 11), including no sideways scrolling at 375 px.

Adjusted checks:
- **Flipped from "hints locked before the attempt" to "hints usable before the attempt; full answer locked":** R3-N0 and the two textbook pre-attempt checks.
- **Changed to match the new order:**
  - R3-N1 no longer expects the hints to unlock at the attempt.
  - R3-N2: H0 before the attempt, H1 after it.
  - The textbook "unlocked after" and "first hint" checks became "hints stay open after" and "next hint opens alone".
  - The textbook reload rung counts.
  - R2-09 (from the first R3 version): the working opens by its own button.
- **New:** Illustration 11, a hint opened before any attempt persists on reload.

Screenshots: `nsep-card-before-attempt.png`, `nsep-card-after-attempt-hints-open.png` and `nsep-card-full-answer-open.png`.

## Still open
- The change is in R3's private copy of the renderer. It is a candidate change to Shared and is **not installed**. Shared tests were NOT_RUN. See RENDERER_CHANGE.md.
- Opening the common wrong route is no longer recorded as an "assistance" marker.
- The open items carried over from R2: the Source chip (NOT_DONE), the transcription re-read, the 19 draft gaps and the "Set_611" HOLD. The D2/D3 difficulty dispute is now closed by the Owner's decision.
- The NSEP card is still not admitted (HOLD). The Owner's decision sets its difficulty only.
- No academic approval inferred from software validation.

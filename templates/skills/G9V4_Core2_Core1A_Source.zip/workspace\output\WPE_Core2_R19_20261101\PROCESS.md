# R19 process record

Paths are relative to `D:/CodeD/grade9v4/workspace/` unless stated. All reads were read-only. Writes: only the four files in this folder. No git writes, no messages, no edits to the reader fix or native records.

## Order of reading
1. `output/WPE_Core2_R19_20261101/BRIEF.md`. Note: the brief itself states R1's settled facts, including that WEP07-03's official key is a, b, c, d and that option (c) prints x₀², and that M101 is a same-force/same-extension comparison.
2. `legacy/g9v3.5/qrt/sources/examside-wpe-extract.json`: `meta`, then for M39, M44, M60, M101 **only** `url`, `paper`, `type`, `stem`, `options`, `figs`, `figure_note` (explanation field deliberately not printed).
3. `legacy/g9v3.5/chatgpt/output/WPE_Core2_Candidate_2026-10-30/data/registry.json`: record structure; for the five IDs `paper`, `collection`, `question_type`, `source`, `stem`, `options`; for WEP07-03 also `question_assets`, `holds`, `source_item_id`, `mode`, `kind` (no answer/prior/assessment fields yet).
4. `…/WPE_Core2_Candidate_2026-10-30/evidence/ae826bc8…13e7.png` (WEP07-03 saved crop) — viewed as an image.

**Solved here, before step 5:** M39 (B), M44 (B), M60 (C), M101 (A), WEP07-03 (a, b, c, d). For the four ExamSIDE items no key or explanation had been seen. For WEP07-03 the solve was not key-blind because of the brief (step 1).

5. Extract `explanation` for M39, M44, M60, M101 (M44's is truncated at 688 characters); registry `answer`, `answer_assets`, `prior`, `holds`, `assessment`, `review`, `status`, `candidate_selected`, `subtopics`, `sl1`, `sl2`, `learner_evidence` for all five.
6. `raw_intake.json`: field-by-field diff against registry for the five IDs; WEP07-03 `prior` and `answer` in full; registry `operations` and `slots`.
7. `subjects/physics/blueprints/physics-blueprint.D3-D4.resolved.v0.2.0.json`: cells D3.1-D3.7 columns/boundaries, D3.6, D4.6, D3.7, D4.7 in full, `common.band_check`, `owner_rules`. Also glanced at the change log of `subtiles/physics-blueprint.D3.v0.2.1.json` (D3.1-only change; not used).
8. D3.6 package `…/WPE_D3_Organized_2026-10-30/packages/WPE_D36_FULL_PACKAGE_R3/`: file list; `01_sources/exam_reconciliation.md`; grep of `ANCHOR_17_LEDGER.md`, `WPE-D3-MAP.md`, `original_adapter_changes.md`, `original_gap_notes.md`; the three `04_topic_adapter/subset_projections/D3.6.*.candidate.json`; scope section of `04_topic_adapter/topic-adapter.work-power-energy.json` (collisions out of scope).
9. D3.7 package `…/WPE_D37_FULL_QUALIFICATION_R5/`: file list; grep for M101 in archived D3.7 `RETURN.md`, `tile-pack.json`, adapter; `01_sources/private/prior_R3_validation/EXAM_RECONCILIATION.json`; the three `04_topic_adapter/subset_projections/D3.7.*.projection.json`; `…/source_validation/questions/NSEP-2025-611-Q57.json`; `05_constructions/R4_witnesses/D47_FOLLOWUP.json`.
10. `legacy/g9v3.5/chatgpt/output/WPE_Core2_Academic_Review_R1_20261031/`: file list, `CORRECTION_NOTICE.md`, `RECONCILIATION_REPORT.md`, `reviewer-return/FINAL_REVIEW.md`; grep of `oracle-research/` for the paper code. Read only after all five solves and after the D3.7 check.
11. `…/WPE_Core2_Candidate_2026-10-30/review/OWNER_REVIEW.md` (grep only; nothing relevant found).
12. R18 summary: not in the local repository (branch absent locally; `git show` failed). Read `docs/core2-r18/README.md` on branch `feat/core2-r18-three-exam-triage-gates` via a read-only `gh api` call to `repos/reallakshman19/Grade9v4.0/contents/...` (locator only; no write).

## What I could not do / did not do
- Official NTA/AIEEE paper and key matching for M39, M44, M60, M101: **NOT_RUN** (not in the files; no web search done).
- Did not open the official PDFs in R1 (`blind-input/official-paper.pdf`, `comparison/official-final-key.pdf`); relied on R1's recorded inspection. The paper code 61 vs Set 611 question is not closed by anything I read.
- Did not read R1's `FIRST_PASS.json` / `FINAL_REVIEW.json` derivations in full, or the D3.6 B1-B7 witnesses.
- Did not find the origin of the Batch 07 SYNTHESIZE D3 proposal for EX-M60 or the Batch 09 JUSTIFY D4 proposal for WEP07-03 in the V4 registry (registry has M60 unassessed and WEP07-03's prior as SYNTHESIZE D4).
- No independent second reviewer; my scores are one reviewer's PROPOSED scores.
- No scripts saved; inline `python -X utf8 -I` reads only. No tests run (none required by the brief).

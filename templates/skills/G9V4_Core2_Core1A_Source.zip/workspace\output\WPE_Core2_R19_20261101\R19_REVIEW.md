# R19 review: last five conditional exam candidates (private)

Reviewer: R19 buddy runner (new agent), 1 Nov 2026. Owner-local, private folder. Question text is quoted here only because this folder is private and Git-excluded.

Status of everything below: **HOLD**. Nothing here is an admission, an approval or an authenticated key. Official NTA paper/key matching for the four JEE/AIEEE items is **NOT_RUN** (not in the files). No learner evidence exists (`learner_evidence: NOT_SUPPLIED`). No academic approval is inferred from software validation.

Factor order everywhere: concept, representation, chain, algebra, trap. Band rule (blueprint v0.2.0 `common.band_check`): D3 = 6-7, D4 = 8-10, below 6 = lower band (D2 or less).

---

## EX-M39 (Batch 07, proposed SYNTHESIZE D3)

### Source identity
- Exam: JEE Main 2024 (Online), 27 January, Evening Shift. Single-correct MCQ. Item located at `examside-wpe-extract.json` `/items/12` (source id M39); registry `EX-M39` binds the same bytes (sha256 cfa7368f…5071, locator /items/12). Registry and raw_intake agree on stem, options and answer fields; they differ only in holds/sl2/assessment/subtopics (assessment added after intake).
- Third-party locator: questions.examside.com page `pa-ball-suspended-by-a-thread-…-x7owvyi0afxo66z7` (locator only, not authentication).
- Key: **none**. `answer.key = null`, `key_kind = UNRESOLVED`; the extract meta says the publisher's marked option was not captured. Only a third-party (ExamSIDE) worked explanation exists, `upstream_authentication: NOT_RUN`.
- Figures: none in stem or options. One explanation image URL (third-party, not downloaded).
- Still unauthenticated: official paper item number within the shift, official stem wording, official NTA key.

Stem (as extracted): "A ball suspended by a thread swings in a vertical plane so that its magnitude of acceleration in the extreme position and lowest position are equal. The angle (θ) of thread deflection in the extreme position will be :" Options A tan⁻¹(1/2), B 2tan⁻¹(1/2), C 2tan⁻¹(1/√5), D tan⁻¹(√2).

### My solve (done before reading the explanation)
Assumptions: point bob, light inextensible thread of length L, no air drag, thread stays taut, "acceleration" is the full vector magnitude.
- Extreme: v = 0, so radial acceleration v²/L = 0; tangential acceleration = g sin θ. |a| = g sin θ.
- Lowest: tangential force zero, so |a| = v²/L; energy from extreme: v² = 2gL(1 − cos θ), so |a| = 2g(1 − cos θ).
- Equate: sin θ = 2(1 − cos θ) → 2 sin(θ/2)cos(θ/2) = 4 sin²(θ/2) → tan(θ/2) = 1/2 (θ ≠ 0) → θ = 2 tan⁻¹(1/2). **Option B.**
- Check: tan(θ/2)=1/2 gives sin θ = 4/5, cos θ = 3/5; 2(1 − 3/5) = 4/5. Consistent.

### Key comparison
Stored explanation (third-party) reaches θ = 2 tan⁻¹(1/2) by the same route. **AGREE** with the explanation. Against an official key: **UNDETERMINED** (no key stored; NTA match NOT_RUN).

### Cell fit
- Deciding move: use energy conservation to supply the bottom speed, then equate the extreme-point tangential acceleration with the bottom radial acceleration. The bridge quantity is v²/L.
- My scores: 1, 1, 2, 1, 1-2 = **6-7 → SYNTHESIZE D3**. Trap: zero speed at the extreme does not mean zero acceleration, and at the bottom only the radial part survives.
- Competing: MODEL (choosing the right acceleration component at each point could be the decisive act). The registry records this as its own competing operation. I keep SYNTHESIZE as primary because each component choice is standard; the dependency between the two points through energy is what decides it. **UNCERTAIN, not settled.**
- Adapter fit (D3.6 R3 package): **PARTIAL**. M39 is family S1 (circular motion + energy) in `WPE-D3-MAP.md` and was the original D3.6 START anchor. But the R3 subset projections bind D3.6.1 to family S5 and D3.6.2 to "S2, S1 prerequisite only"; no R3 subset owns S1 as a primary family. The 17-anchor ledger says "D3.6.1 candidate" — that disagrees with the D3.6.1 projection (S5). Circular-motion/radial-acceleration prerequisites are recorded as not canonically qualified.

### Conflicts flagged (not resolved)
1. Score: `WPE-D3-MAP.md` says 7; `ANCHOR_17_LEDGER.md` and registry say 1/1/2/1/1 = 6. Both are D3, so band is unaffected.
2. Subtile home: ledger "D3.6.1 candidate" vs D3.6.1 projection family S5.

### Gates
HOLD: official paper item and NTA key not bound; independent source, key and QRT reviews missing; circular-motion prerequisite not qualified in the WPE adapter; no learner evidence.

---

## EX-M44 (Batch 07, proposed SYNTHESIZE D3)

### Source identity
- Exam: JEE Main 2023 (Online), 8 April, Evening Shift. Single-correct MCQ. Extract `/items/13` (M44); registry `EX-M44`, same evidence bytes.
- Locator: examside page `pa-bullet-of-mass-01-mathrmkg-…-upztibifurmxw8xk`.
- Key: **none** (`key = null`, UNRESOLVED). The third-party explanation is **truncated** (688 characters; it stops mid-sentence after computing the shared speed and never states μ or an option).
- Figures: none.
- Still unauthenticated: official item, stem, key; the stored explanation is incomplete.

Stem: "A bullet of mass 0.1kg moving horizontally with speed 400 m s⁻¹ hits a wooden block of mass 3.9kg kept on a horizontal rough surface. The bullet gets embedded into the block and moves 20m before coming to rest. The coefficient of friction between the block and the surface is ____. (Given g=10 m/s²)" Options A 0.65, B 0.25, C 0.50, D 0.90.

### My solve
Assumptions: embedding is effectively instantaneous, so friction impulse during impact is negligible and horizontal momentum is conserved across the impact; the block does not move during embedding; kinetic friction constant μ(M+m)g afterwards; level surface; "moves 20 m" means the combined body slides 20 m after impact.
- Momentum: 0.1 × 400 = 4.0 V → V = 10 m/s.
- Stopping: ½(4)V² = μ(4)(10)(20) → 100 = 400 μ → μ = **0.25. Option B.**
- Trap check: using the bullet's own KE (8000 J) instead gives μ = 10, not an option — energy is lost in embedding.

### Key comparison
Explanation agrees up to V = 10 m/s and then truncates. **UNDETERMINED**: partial agreement only; no complete explanation and no key to compare the final value against.

### Cell fit
- Deciding move: recognise two stages governed by different laws (momentum for the impact, work-energy with friction for the slide) and carry the shared post-impact speed across.
- My scores: 1, 1, 2, 1, 1-2 = **6-7 → SYNTHESIZE D3** on demand. MODEL is a real competitor (choosing the right law per interval). **UNCERTAIN.**
- Adapter fit (D3.6): **OUT_OF_SCOPE**. The WPE topic adapter's `scope.known_source_gaps` says collisions are out of scope unless the Owner adds a source; `exam_reconciliation.md` says M44/M60 are to be preserved and quarantined, not claimed as WPE scope. The ledger marks M44 `HOLD_OUT_OF_SCOPE`. Family S3 ("collision first, then friction") is in the map but has no R3 subset projection.

### Conflicts flagged
1. Registry slot SYNTHESIZE-3 nominates EX-M44, while the D3.6 package classifies it HOLD_OUT_OF_SCOPE. Cross-package conflict.
2. Score: registry 1/1/2/1/2 = 7 vs ledger 1/1/2/1/1 = 6.

### Gates
HOLD: collision scope needs an Owner decision (and a source) before any WPE admission; explanation truncated; official item/key not bound; independent reviews missing.

---

## EX-M60 (Batch 07, proposed SYNTHESIZE D3)

### Source identity
- Exam: JEE Main 2021 (Online), 31 August, Evening Shift. Single-correct MCQ. Extract `/items/18` (M60); registry `EX-M60`.
- Locator: examside page `a-block-moving-horizontally-on-a-smooth-surface-…-b0dzdrqrlu9fo6cs` (note: page slug files it under "units and measurements").
- Key: none (UNRESOLVED). Third-party explanation complete. One explanation image URL (not downloaded). No stem figures.
- Registry status: `UNASSESSED / HOLD`, `candidate_selected: false`, `assessment: null`, `sl2: null`, and **no QRT slot** names EX-M60.

Stem: "A block moving horizontally on a smooth surface with a speed of 40 m/s splits into two parts with masses in the ratio of 1 : 2. If the smaller part moves at 60 m/s in the same direction, then the fractional change in kinetic energy is :-" Options A 1/3, B 2/3, C 1/8, D 1/4.

### My solve
Assumptions: smooth horizontal surface, so no horizontal external impulse during the split; both fragments move along the original line; internal energy release allowed; "fractional change" = (K_f − K_i)/K_i, sign positive here.
- Masses m and 2m. 3m(40) = m(60) + 2m v → v = 30 m/s, same direction.
- K_i = ½(3m)(1600) = 2400m; K_f = ½m(3600) + ½(2m)(900) = 1800m + 900m = 2700m.
- ΔK/K_i = 300/2400 = **1/8. Option C.**

### Key comparison
Explanation gives (3600 + 1800 − 4800)/4800 = 1/8. **AGREE** with explanation; official key UNDETERMINED.

### Cell fit
- Deciding move: momentum conservation fixes the second fragment's speed; the KE ratio is then direct substitution.
- My scores: 1, 0-1, 1, 1, 1 = **4-5 → APPLY, lower band (D2)**. The two steps are routine and the bridge is not hidden.
- **DISAGREE with SYNTHESIZE D3.** The D3.6 ledger independently scored it APPLY 1/0/1/1/1 = 4, D2; `WPE-D3-MAP.md` lists it as a level-2 bridge (5).
- Adapter fit: **OUT_OF_SCOPE** (splitting/collision, same as M44), and below band.

### Conflicts flagged
1. The brief's Batch 07 proposal (SYNTHESIZE D3) is not traceable to the V4 registry: the registry has M60 unassessed and unselected. I could not find in the files who proposed SYNTHESIZE D3 for M60.
2. Proposal vs ledger: SYNTHESIZE D3 vs APPLY D2 (4).

### Gates
HOLD: below D3 on my reading and the ledger's; out of WPE scope; no assessment record; official item/key not bound.

---

## EX-M101 (Batch 08, proposed JUSTIFY D3)

### Source identity
- Exam: AIEEE 2012 (single paper; no shift). Single-correct MCQ, two-statement format. Extract `/items/42` (M101); registry `EX-M101`.
- Locator: examside page `this-question-has-statement-1-and-statement-2-of-th-2012-marks-4-ky02pg1xjz6d8kdg.htm`.
- Key: none (UNRESOLVED). Third-party explanation complete. No figures.
- D3.7 package `EXAM_RECONCILIATION.json`: authentic official stem HOLD, official key HOLD, publisher extract only.

Stem: "If two springs S₁ and S₂ of force constants k₁ and k₂, respectively, are stretched by the same force, it is found that more work is done on spring S₁ than on spring S₂. STATEMENT 1: If stretched by the same amount, work done on S₁ is more than that on S₂. STATEMENT 2: k₁ < k₂." Options A S1 false, S2 true; B S1 true, S2 false; C both true, S2 explains S1; D both true, S2 does not explain S1.

### My solve
Assumptions: ideal Hookean massless springs, stretched quasi-statically from natural length; "work done on the spring" = stored elastic energy.
- Same force F: x = F/k, W = F²/(2k). W₁ > W₂ → k₁ < k₂. **Statement 2 true.**
- Same extension x: W = ½kx², so W₁/W₂ = k₁/k₂ < 1 → W₁ < W₂. **Statement 1 false.**
- **Option A.**

### Key comparison
Explanation reaches A by the same two forms. **AGREE** with explanation; official key UNDETERMINED. Consistent with the archived D3.7 build ("M101 A … agree with publisher explanations").

### Settled facts read after my solve (R1)
R1 settles that M101 is a same-force/same-extension comparison, not the cut-spring problem — my solve agrees. The R1 independent reviewer (blind first pass, sealed) scored it APPLY 1/1/1/0/1 = 4, D2.

### Cell fit
- Deciding move: notice that the controlled variable switches (fixed force → W ∝ 1/k; fixed extension → W ∝ k), so the stiffness ordering reverses the work ordering.
- My scores: 1, 1, 1, 0-1, 1-2 = **4-5 → APPLY, D2**.
- **I agree with APPLY D2, not JUSTIFY D3.** Reason: the MCQ only needs two familiar formulas and an inequality. It does not require the learner to state warrant and conditions, or handle a boundary case, which is the D3.7 evidence criterion. The assertion-reason format does not by itself make JUSTIFY the primary operation. The trap (reversal) is real but carries at most 2 points; chain length is 1, not 2.
- Adapter fit (D3.7 R5): **PARTIAL / HOLD**. M101 was START in the archived D3.7 build (J2 family, "same force vs same stretch"), and is bound to subset D3.7.2. The D3.7.2 projection is `status: HOLD` (spring authority pin and novelty acceptance outstanding); its MAIN is the authored cut-spring task, which is a different item.

### Conflicts flagged
1. Registry/sl2 JUSTIFY 1/1/2/1/2 = 7 (D3) vs `WPE-D3-MAP.md` 1/0/2/1/2 = 6 vs R1 independent APPLY 4 (D2) vs mine APPLY 4-5 (D2). The registry already holds `JUSTIFY_VS_APPLY_REQUIRES_INDEPENDENT_ADJUDICATION`.
2. Registry slot JUSTIFY-1 still nominates M101 at D3; R1's reconciliation has it lower-band. The registry was not updated (not my job; flagged).

### Gates
HOLD: operation/band adjudication (two reviews now point to APPLY D2, so it does not fill a JUSTIFY D3 slot on current evidence); official AIEEE 2012 paper/key not bound; D3.7.2 projection HOLD.

---

## WEP07-03 (Batch 09, proposed JUSTIFY D4)

### Source identity
- Exam: NSEP 2025 (IAPT National Standard Examination in Physics), question 57, multi-correct MCQ. **Not JEE Main** — provenance must stay distinct.
- V4 registry `WEP07-03`: paper "NSEP 2025 code 61 Q57", collection "NSEP extension". Stem/options are **not** extracted (`stem: null`, hold `EXACT_TEXT_EXTRACTION_NOT_COMPLETED`); the item exists as a saved crop PNG (sha256 ae826bc8…13e7, role SAVED_ITEM_CROP, `PENDING_WITNESS`). I read the stem from that crop.
- D3.7 package `NSEP-2025-611-Q57.json` ties the same crop hash to a paper PDF member `NSEP_-_2025_Set_611.pdf` (sha256 c3e5770f…5973), "p15 Q57".
- Key: registry `key_kind: INHERITED_CLAIM`, a,b,c,d. R1 (read after my solve) records that the official IAPT final NSEP 2025 key, official worked solution and the official paper were retrieved and agree on a,b,c,d. Locator only: iapt.org.in `NSEP_-_2025_Final_Answer_Key.pdf`. This is the only one of the five with an official key in the files.
- Figures: none (crop is text only).
- Still open: registry hold `PAPER_CODE_61_VS_611_RECONCILIATION` — R1 says "code61", the D3.7 package says "Set 611"; I found no file that explicitly closes this. Registry still lists `OFFICIAL_KEY_NOT_RETAINED` / `OFFICIAL_KEY_ITEM_NOT_BOUND`, which R1's retrieval supersedes in substance but the registry record itself is unchanged.

Stem (from crop): "A particle of mass m moves along x axis with its potential energy as U(x) = α/x² − β/x where α and β are positive constants. The particle is released from rest at x₀ = α/β. Then (a) U(x) can be expressed as U(x) = (α/x₀²)[(x₀/x)² − x₀/x]; (b) v(x) = [(2α/(m x₀²)){x₀/x − (x₀/x)²}]^½; (c) the maximum speed is v_max = √(α/(2m x₀²)); (d) the total energy KE(x)+U(x) is zero."

### My solve (from the crop, before reading the registry key, the D3.7 file or R1)
Disclosure: this solve was **not key-blind**. The R19 brief itself states that the official NSEP 2025 key is a, b, c, d and that option (c) prints x₀², and I read the brief first. My derivation below is complete on its own, but it is not independent evidence about the key in the way a blind solve would be.
Assumptions: one-dimensional, conservative force only, non-relativistic, motion on x > 0, released exactly at rest.
- (a) β = α/x₀ → U = α/x² − α/(x₀x) = (α/x₀²)[(x₀/x)² − x₀/x]. **True.**
- (d) U(x₀) = (α/x₀²)(1 − 1) = 0 and K = 0, so E = 0 and stays 0. **True.**
- (b) ½mv² = −U → v² = (2α/(m x₀²))[x₀/x − (x₀/x)²]. **True** (on the allowed region x ≥ x₀, where the bracket ≥ 0).
- Direction: F = −dU/dx = 2α/x³ − β/x²; at x₀ this is β³/α² > 0, so it moves outward; x < x₀ would need U > 0 = E, forbidden.
- (c) With z = x₀/x ∈ (0,1], z − z² ≤ 1/4 at z = ½ (x = 2x₀) → v_max² = α/(2m x₀²). **True.**
- **Answer a, b, c, d.**

### Key comparison
**AGREE** with the registry's inherited claim and, per R1, with the official IAPT final key and worked solution. Option (c) prints x₀² (R1 settled; the old "source conflict" is withdrawn — my reading of the crop also shows x₀²).

### Cell fit
- Deciding move: notice U(x₀) = 0 so E = 0, then K = −U gives every option; max speed by completing the square.
- My scores: 1, 0-1, 2, 1, 0-1 = **4-6 → APPLY, D2 (upper edge of D2, possibly low D3)**. The supplied forms in (a)-(c) let a learner verify rather than derive.
- **I agree with APPLY D2 (R1 independent: 1/0/2/1/1 = 5), not JUSTIFY D4.** Reason: nothing in the original item asks to prove or refute a claim whose converse or boundary fails (the D4.7 attempt pattern); all four claims are simply true and checkable by substitution. The JUSTIFY D4 score 9 in the D3.7 package (`NSEP-2025-611-Q57.json`, factors 2/1/2/2/2) belongs to an **author-created probe** ("it must have positive total energy because it moves" → refute), recorded there as `ORIGINAL_SOURCE_QUESTION_PLUS_AUTHOR_CREATED_JUSTIFY_PROBE`. That score cannot be carried over to the original exam item.
- Adapter fit: **no D4 adapter slice exists.** D4.7 has only `R4_witnesses/D47_FOLLOWUP.json` (status PARTIAL, MAIN HOLD; "do not copy current D3 MAIN score into D4"; "do not treat authored transfer as original exam evidence"). D4.6 has no slice in the D3.6 package. In D3.7 the item sits under subset D3.7.3 as an "ADVANCED_D4_STRESS_TEST".

### Conflicts flagged
1. Four different classifications on file: registry `prior` SYNTHESIZE D4 (8); D3.7 package JUSTIFY D4 (9, but for the authored probe); Batch 09 proposal JUSTIFY D4; R1 independent APPLY D2 (5). Mine: APPLY D2.
2. Paper code 61 vs Set 611 still unreconciled in the files I read.

### Gates
HOLD: cell — on two reviews it is APPLY D2, so it does not fill a JUSTIFY D4 slot; exact text extraction not completed in the registry; 61/611 reconciliation; official key bound in R1 research but not yet into the registry record; Owner decision on whether a D2 NSEP item may be admitted as labelled support.

---

## Closest to admission (all 14 candidates)

The 14 = R18's nine (M105, M62, M79, M16, M73, M81, M56, M61, M69; read from public PR 18 README, locator only) + these five.

**Pick: WEP07-03 (NSEP 2025 Q57).**

Why: it is the only one of the 14 with an official paper, an official final key and an official worked solution in the files, all agreeing; a sealed blind independent review agreeing on the answer; my own full derivation agreeing (not key-blind, since the brief disclosed the key); and no figure dependency. Every JEE/AIEEE candidate among the 14 still has its official NTA paper/key match NOT_RUN, and several (M56, M61, M69) depend on unauthenticated graph figures, M44 has a truncated explanation, and M44/M60 are out of WPE scope.

What is still missing for a first end-to-end admission:
1. **Cell decision by the Owner.** Its supported cell is APPLY D2, not JUSTIFY D4. Admission can only be as a correctly labelled lower-band (D2) exam question, not as D4 coverage. If the Owner requires a D3/D4 slot for the first admission, WEP07-03 does not qualify, and the next best is **EX-M39** (SYNTHESIZE D3, physics consistent, no figure), which still lacks the official NTA paper item and key.
2. Record-level binding: write the R1 official key/paper evidence into the WEP07-03 record (registry still says `OFFICIAL_KEY_NOT_RETAINED` / `ITEM_NOT_BOUND`), and close the **code 61 vs Set 611** hold.
3. Exact text extraction of the stem and four options from the paper (registry `stem: null`), checked against the crop.
4. A native rendered question page from that text, checked by someone other than the author (technical QA NOT_RUN for a real exam item; R1 says the adapter has only shown a synthetic profile).
5. Owner acceptance of provenance/rights for an NSEP item in private self-study use, and Owner approval of the admission itself.

None of this is done by R19. Admissions remain zero.

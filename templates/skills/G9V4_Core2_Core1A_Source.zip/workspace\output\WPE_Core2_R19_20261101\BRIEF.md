# R19 brief: buddy runner (new agent), 1 Nov 2026

From: the Grade9 v4 Oracle, standing in for the Owner.

## Owner's intent, in the Owner's words
- "Let A19 be done via buddy runner (New agent) and let outgoing agent check the process and the output."
- The project: a private self-study course in Physics/Maths/Chemistry towards JEE Main. Work, Power and Energy (WPE) is the Physics pilot. Each question is placed in the QRT grid (kind of thinking x difficulty level) by the one move that decides it.
- The outgoing ChatGPT agent (A1) itself said the next milestone must be "one independently admitted examination question rendered correctly, not another collection of reports". So R19 closes the review of the last five candidates and then names which candidate is closest to admission.

## The one task
Review the last five conditional exam candidates. It's the same kind of review A1 did for nine in R18, but you work from V4's own local sources:

| Batch | Proposed cell | IDs |
|---|---|---|
| 07 | SYNTHESIZE D3 (multi-step) | EX-M39, EX-M44, EX-M60 |
| 08 | JUSTIFY D3 | EX-M101 |
| 09 | JUSTIFY D4 | WEP07-03 |

For each ID:
1. **Source identity:** find it in V4 (`workspace/legacy/g9v3.5/qrt/sources/examside-wpe-extract.json`, `workspace/legacy/g9v3.5/chatgpt/output/WPE_Core2_Candidate_2026-10-30/data/registry.json` and `raw_intake.json`). Record the exam, year and shift, item, the key available and whether it is official or third-party, any figures, and what is still unauthenticated.
2. **Physics:**
   - Solve it yourself first, before you read any prior answer or explanation. Write down every model assumption.
   - Then compare with the stored key and explanation. Mark AGREE, DISAGREE or UNDETERMINED, with the reason.
3. **Cell fit:**
   - Propose the one deciding move, the QRT operation and the level, against the Physics blueprint `workspace/subjects/physics/blueprints/physics-blueprint.D3-D4.resolved.v0.2.0.json`.
   - Check fit with the cell's draft adapter: SYNTHESIZE D3.6 and JUSTIFY D3.7 candidates under `workspace/legacy/g9v3.5/chatgpt/output/WPE_D3_Organized_2026-10-30/packages/WPE_D36_FULL_PACKAGE_R3/` and `WPE_D37_FULL_QUALIFICATION_R5/`. For D4, say whether any adapter slice exists.
   - Flag conflicts with earlier classifications rather than resolving them silently.
4. **For M101 and WEP07-03 only:** after your own solve, read `workspace/legacy/g9v3.5/chatgpt/output/WPE_Core2_Academic_Review_R1_20261031/` (CORRECTION_NOTICE.md, RECONCILIATION_REPORT.md, reviewer-return/). Facts already settled there:
   - WEP07-03's source prints x0², and the official NSEP 2025 key agrees with a, b, c, d. The old "source conflict" claim is WITHDRAWN.
   - M101 is a same-force/same-extension spring comparison, not the cut-spring problem.
   - Earlier reviewers rated both APPLY D2. Say whether you agree with JUSTIFY D3/D4 or with APPLY D2, and why.

Then add one closing section, **Closest to admission:** across all 14 candidates (R18's 9 are summarised in public PR 18, `docs/core2-r18/README.md` on branch `feat/core2-r18-three-exam-triage-gates`), which single question has the strongest evidence for a first end-to-end admission, and what exactly is still missing for it.

## Rules
- Read-only on everything that exists. Write only in `D:/CodeD/grade9v4/workspace/output/WPE_Core2_R19_20261101/`.
- No git commits, pushes, PRs or GitHub comments. No messages to anyone. No web access is needed. If you use any, give the URL as a locator only, never as authentication.
- `workspace/` is private and Git-excluded. Never copy question text, options, keys or figures anywhere outside it.
- Do not change the corrected reader (`workspace/output/WPE_Core2_Reader_Fix_R1_20261031/`) or any native record.
- Never claim an admission, approval or authenticated key. Anything not established is HOLD; anything not run is NOT_RUN.
- Don't guess the exam paper's identity or the official key. If it isn't in the files, say so.

## Return (in that folder)
1. `R19_REVIEW.md`: one section per ID (source identity, your solve and assumptions, key comparison, cell fit, conflicts, gates), then "Closest to admission". Plain words. Question text may be quoted here, since the folder is private.
2. `R19_REGISTER.csv`: id, batch, proposed_cell, your_cell, physics_vs_key, source_status, adapter_fit, gate, next_evidence.
3. `R19_FOR_A1.md`: the same findings with **no** question text, options, numbers from the stem, or keys. IDs, verdicts, reasons and gates only. It goes to the outgoing agent for a process check.
4. `PROCESS.md`: exactly which files you read, in what order, what you solved before seeing keys, and anything you could not do.

Final reply to the Oracle: at most 150 words. Per ID: verdict and gate. Then the closest-to-admission pick.
